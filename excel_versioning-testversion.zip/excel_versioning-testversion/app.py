"""
Excel and ZIP File Data Versioning Web Application
This application allows users to view differences in Excel and ZIP files
between different commits in a GitHub repository or versions in GCS bucket.
Supports both local repositories, remote GitHub repositories, and GCS buckets.
"""

from flask import Flask, render_template, request, jsonify, session
import os
import subprocess
import pandas as pd
import zipfile
from io import BytesIO
import tempfile
import shutil
from urllib.parse import urlparse
import hashlib
import json
import difflib
import re
from datetime import datetime
from google.cloud import storage
from google.api_core import exceptions as gcs_exceptions
import logging

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24).hex())

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Constants for binary file detection
MAX_NULL_BYTE_RATIO = 0.01  # Max 1% null bytes before treating as binary
MAX_CONTROL_CHAR_RATIO = 0.3  # Max 30% control chars before treating as binary

# Configuration
DEFAULT_REPO_PATH = os.getcwd()
TEMP_REPOS_DIR = tempfile.mkdtemp(prefix='git_repos_')

# Cleanup temp directory on exit
import atexit
import math

@atexit.register
def cleanup_temp_repos():
    """Clean up temporary repositories directory on exit."""
    try:
        if os.path.exists(TEMP_REPOS_DIR):
            shutil.rmtree(TEMP_REPOS_DIR)
            logger.info(f"Cleaned up temporary directory: {TEMP_REPOS_DIR}")
    except Exception as e:
        logger.error(f"Error cleaning up temp directory: {e}")


def sanitize_for_json(obj):
    """Recursively sanitize data structure to ensure JSON serialization.
    
    Replaces NaN, Infinity, and -Infinity with None to avoid JSON errors.
    """
    if isinstance(obj, dict):
        return {key: sanitize_for_json(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [sanitize_for_json(item) for item in obj]
    elif isinstance(obj, float):
        if math.isnan(obj) or math.isinf(obj):
            return None
        return obj
    else:
        return obj



def get_repo_path():
    """Get the current repository path from session or default."""
    return session.get('repo_path', DEFAULT_REPO_PATH)


def get_storage_mode():
    """Get the current storage mode (git, github, or gcs)."""
    return session.get('storage_mode', 'git')


def get_gcs_config():
    """Get GCS bucket configuration from session."""
    return {
        'bucket_name': session.get('gcs_bucket_name'),
        'prefix': session.get('gcs_prefix', '')
    }


def create_gcs_client():
    """Create a GCS storage client with proper credential handling.
    
    Returns:
        storage.Client object
        
    Raises:
        Exception: If credentials are not properly configured
    """
    try:
        # The client will look for credentials in this order:
        # 1. GOOGLE_APPLICATION_CREDENTIALS environment variable
        # 2. gcloud auth application-default login credentials
        # 3. Metadata server (for GCP environments)
        return storage.Client()
    except Exception as e:
        error_msg = str(e).lower()
        # Check for common authentication-related errors
        if any(keyword in error_msg for keyword in ["email", "metadata", "credentials", "default credentials", "adc"]):
            raise Exception(
                "Authentication failed. Please authenticate using one of these methods:\n"
                "1. Run 'gcloud auth application-default login' in your terminal\n"
                "2. Set GOOGLE_APPLICATION_CREDENTIALS to point to a service account JSON key file\n"
                "3. If running in GCP, ensure the service account has proper IAM permissions"
            )
        raise


def connect_to_gcs_bucket(bucket_name, prefix=''):
    """Connect to a GCS bucket and verify access."""
    try:
        logger.info(f"Attempting to connect to GCS bucket: {bucket_name}, prefix: {prefix}")
        
        # Create client with proper credential handling
        client = create_gcs_client()
        bucket = client.bucket(bucket_name)
        
        # Verify bucket exists and we have access
        if not bucket.exists():
            logger.error(f"Bucket '{bucket_name}' does not exist or access denied")
            return None, f"Bucket '{bucket_name}' does not exist or you don't have access"
        
        # Check if versioning is enabled
        bucket.reload()
        if not bucket.versioning_enabled:
            logger.error(f"Versioning not enabled on bucket '{bucket_name}'")
            return None, f"Versioning is not enabled on bucket '{bucket_name}'. Please enable it first."
        
        # Store in session
        session['storage_mode'] = 'gcs'
        session['gcs_bucket_name'] = bucket_name
        session['gcs_prefix'] = prefix
        
        logger.info(f"Successfully connected to GCS bucket: {bucket_name}")
        return bucket_name, None
    except gcs_exceptions.Forbidden:
        logger.error("GCS access denied - authentication issue")
        return None, "Access denied. Make sure you're authenticated with 'gcloud auth application-default login'"
    except gcs_exceptions.NotFound:
        logger.error(f"GCS bucket '{bucket_name}' not found")
        return None, f"Bucket '{bucket_name}' not found"
    except Exception as e:
        logger.error(f"Error connecting to GCS: {e}")
        return None, f"Error connecting to GCS: {str(e)}"


def get_gcs_file_versions(bucket_name, file_path, prefix=''):
    """Get all versions of a file from GCS bucket."""
    try:
        client = create_gcs_client()
        bucket = client.bucket(bucket_name)
        
        # Add prefix to file path if specified
        full_path = f"{prefix}/{file_path}".strip('/') if prefix else file_path
        
        # List all versions of the blob
        blobs = list(bucket.list_blobs(prefix=full_path, versions=True))
        
        # Filter to exact matches (not prefixes)
        versions = []
        for blob in blobs:
            if blob.name == full_path:
                versions.append({
                    'generation': str(blob.generation),  # String for JSON (converted to int when needed)
                    'time_created': blob.time_created.isoformat() if blob.time_created else '',
                    'updated': blob.updated.isoformat() if blob.updated else '',
                    'size': blob.size,
                    'name': blob.name,
                    'metageneration': blob.metageneration
                })
        
        # Sort by time_created descending (newest first)
        versions.sort(key=lambda x: x['time_created'], reverse=True)
        
        logger.info(f"Found {len(versions)} versions for {full_path}")
        return versions
    except Exception as e:
        logger.error(f"Error getting GCS file versions: {e}")
        return []


def get_gcs_files(bucket_name, prefix='', file_extensions=('.xlsx', '.xls', '.zip')):
    """Get list of files in GCS bucket with specified extensions.
    
    Args:
        bucket_name: Name of the GCS bucket
        prefix: Optional prefix/folder path to filter files
        file_extensions: Tuple of file extensions to include (default: .xlsx, .xls, .zip)
                        Use this parameter to filter which file types are returned.
                        For example, passing ('.xlsx', '.xls') will return only Excel files.
    
    Returns:
        List of file paths (with prefix removed) that match the specified extensions
    """
    try:
        client = create_gcs_client()
        bucket = client.bucket(bucket_name)
        
        # List blobs (not including versions, just current)
        blobs = bucket.list_blobs(prefix=prefix)
        
        files = []
        seen = set()
        for blob in blobs:
            # Only include files with specified extensions
            if any(blob.name.lower().endswith(ext) for ext in file_extensions):
                # Remove prefix from display name
                display_name = blob.name
                if prefix and display_name.startswith(prefix):
                    display_name = display_name[len(prefix):].lstrip('/')
                
                if display_name not in seen:
                    files.append(display_name)
                    seen.add(display_name)
        
        logger.info(f"Found {len(files)} files in GCS bucket {bucket_name} with extensions {file_extensions}")
        return files
    except Exception as e:
        logger.error(f"Error getting GCS files: {e}")
        return []


def download_gcs_file_version(bucket_name, file_path, generation=None, prefix=''):
    """Download a specific version of a file from GCS."""
    try:
        client = create_gcs_client()
        bucket = client.bucket(bucket_name)
        
        # Add prefix to file path if specified
        full_path = f"{prefix}/{file_path}".strip('/') if prefix else file_path
        
        # Get the blob with specific generation
        if generation:
            blob = bucket.blob(full_path, generation=int(generation))  # Convert back to int for GCS API
        else:
            blob = bucket.blob(full_path)
        
        # Download to bytes
        content = blob.download_as_bytes()
        logger.info(f"Downloaded {full_path} (generation: {generation}, size: {len(content)} bytes)")
        return content
    except Exception as e:
        logger.error(f"Error downloading GCS file {file_path} (generation: {generation}): {e}")
        return None


def clone_or_update_repo(github_url, token=None):
    """Clone or update a repository from GitHub."""
    try:
        # Parse the URL to get repo name
        parsed_url = urlparse(github_url)
        repo_name = parsed_url.path.strip('/').replace('/', '_')
        
        # Ensure .git extension
        clean_url = github_url if github_url.endswith('.git') else github_url + '.git'
        
        repo_path = os.path.join(TEMP_REPOS_DIR, repo_name)
        
        # Set up environment with token if provided
        env = os.environ.copy()
        if token:
            # Use GIT_ASKPASS to provide credentials securely
            env['GIT_TERMINAL_PROMPT'] = '0'
            # Create authenticated URL for git operations
            auth_url = clean_url.replace('https://', f'https://{token}@')
        else:
            auth_url = clean_url
        
        # Check if repo already exists
        if os.path.exists(repo_path):
            # Update existing repo
            print(f"Updating repository at {repo_path}")
            result = subprocess.run(
                ['git', 'fetch', '--all'],
                cwd=repo_path,
                capture_output=True,
                text=True,
                timeout=60,
                env=env
            )
            if result.returncode != 0:
                # Don't expose token in error messages
                error_msg = result.stderr.replace(token if token else '', '***') if token else result.stderr
                return None, f"Failed to update repository: {error_msg}"
        else:
            # Clone new repo
            print(f"Cloning repository to {repo_path}")
            result = subprocess.run(
                ['git', 'clone', auth_url, repo_path],
                capture_output=True,
                text=True,
                timeout=120,
                env=env
            )
            if result.returncode != 0:
                # Don't expose token in error messages
                error_msg = result.stderr.replace(token if token else '', '***') if token else result.stderr
                return None, f"Failed to clone repository: {error_msg}"
        
        return repo_path, None
    except subprocess.TimeoutExpired:
        return None, "Operation timed out. Please check your network connection."
    except Exception as e:
        return None, f"Error: {str(e)}"


def get_all_commits():
    """Get list of all commits with their hash and message."""
    try:
        repo_path = get_repo_path()
        is_github = repo_path != DEFAULT_REPO_PATH
        
        # When connected to GitHub, use --all to see commits from all branches including remote tracking branches
        # This ensures fetched commits from remote are visible
        git_log_cmd = ['git', 'log', '--pretty=format:%H|||%s|||%an|||%ad', '--date=short']
        if is_github:
            git_log_cmd.insert(2, '--all')  # Insert --all after 'git log'
        
        result = subprocess.run(
            git_log_cmd,
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True
        )
        commits = []
        for line in result.stdout.strip().split('\n'):
            if line:
                parts = line.split('|||')
                if len(parts) >= 4:
                    commits.append({
                        'hash': parts[0],
                        'message': parts[1],
                        'author': parts[2],
                        'date': parts[3]
                    })
        return commits
    except subprocess.CalledProcessError as e:
        print(f"Error getting commits: {e}")
        return []


def get_branches():
    """Get list of all branches in the repository."""
    try:
        repo_path = get_repo_path()
        is_github = repo_path != DEFAULT_REPO_PATH
        
        # Get local and remote branches
        if is_github:
            # For GitHub repos, show remote branches
            result = subprocess.run(
                ['git', 'branch', '-r'],
                cwd=repo_path,
                capture_output=True,
                text=True,
                check=True
            )
        else:
            # For local repos, show local branches
            result = subprocess.run(
                ['git', 'branch'],
                cwd=repo_path,
                capture_output=True,
                text=True,
                check=True
            )
        
        branches = []
        for line in result.stdout.strip().split('\n'):
            if line:
                # Remove * and whitespace
                branch = line.strip().lstrip('* ').strip()
                # Skip HEAD pointer
                if '-> ' not in branch and branch:
                    branches.append(branch)
        
        return branches
    except subprocess.CalledProcessError as e:
        print(f"Error getting branches: {e}")
        return []


def get_commits_for_branch(branch):
    """Get list of commits for a specific branch."""
    try:
        repo_path = get_repo_path()
        
        result = subprocess.run(
            ['git', 'log', branch, '--pretty=format:%H|||%s|||%an|||%ad', '--date=short'],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True
        )
        commits = []
        for line in result.stdout.strip().split('\n'):
            if line:
                parts = line.split('|||')
                if len(parts) >= 4:
                    commits.append({
                        'hash': parts[0],
                        'message': parts[1],
                        'author': parts[2],
                        'date': parts[3]
                    })
        return commits
    except subprocess.CalledProcessError as e:
        print(f"Error getting commits for branch: {e}")
        return []


def get_all_commits():
    """Get list of all commits with their hash and message."""
    try:
        repo_path = get_repo_path()
        is_github = repo_path != DEFAULT_REPO_PATH
        
        # When connected to GitHub, use --all to see commits from all branches including remote tracking branches
        # This ensures fetched commits from remote are visible
        git_log_cmd = ['git', 'log', '--pretty=format:%H|||%s|||%an|||%ad', '--date=short']
        if is_github:
            git_log_cmd.insert(2, '--all')  # Insert --all after 'git log'
        
        result = subprocess.run(
            git_log_cmd,
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True
        )
        commits = []
        for line in result.stdout.strip().split('\n'):
            if line:
                parts = line.split('|||')
                if len(parts) >= 4:
                    commits.append({
                        'hash': parts[0],
                        'message': parts[1],
                        'author': parts[2],
                        'date': parts[3]
                    })
        return commits
    except subprocess.CalledProcessError as e:
        print(f"Error getting commits: {e}")
        return []


def get_files_at_commit(commit_hash):
    """Get list of Excel and ZIP files at a specific commit."""
    try:
        repo_path = get_repo_path()
        result = subprocess.run(
            ['git', 'ls-tree', '-r', '--name-only', commit_hash],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True
        )
        files = result.stdout.strip().split('\n')
        # Filter for Excel and ZIP files
        filtered_files = [
            f for f in files 
            if f.lower().endswith(('.xlsx', '.xls', '.zip'))
        ]
        return filtered_files
    except subprocess.CalledProcessError as e:
        print(f"Error getting files: {e}")
        return []


def get_files_for_branch(branch):
    """Get list of Excel and ZIP files for a specific branch."""
    try:
        repo_path = get_repo_path()
        
        # Validate branch exists
        branches = get_branches()
        if branch not in branches:
            print(f"Invalid branch: {branch}")
            return []
        
        # Use the branch name to list files
        result = subprocess.run(
            ['git', 'ls-tree', '-r', '--name-only', branch],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True
        )
        
        # Handle empty output
        if not result.stdout.strip():
            return []
            
        files = result.stdout.strip().split('\n')
        # Filter for Excel and ZIP files, excluding empty strings
        filtered_files = [
            f for f in files 
            if f and f.lower().endswith(('.xlsx', '.xls', '.zip'))
        ]
        return filtered_files
    except subprocess.CalledProcessError as e:
        print(f"Error getting files for branch: {e}")
        return []


def get_commits_for_file(branch, file_path):
    """Get list of commits that modified a specific file in a branch."""
    try:
        repo_path = get_repo_path()
        
        # Validate branch exists
        branches = get_branches()
        if branch not in branches:
            print(f"Invalid branch: {branch}")
            return []
        
        # Sanitize file path to prevent directory traversal
        # Remove any leading slashes and resolve to canonical path
        file_path = file_path.lstrip('/')
        if '..' in file_path or file_path.startswith('/'):
            print(f"Invalid file path: {file_path}")
            return []
        
        # Use git log with file path to get only commits that modified this file
        result = subprocess.run(
            ['git', 'log', branch, '--pretty=format:%H|||%s|||%an|||%ad', '--date=short', '--', file_path],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True
        )
        
        # Handle empty output
        if not result.stdout.strip():
            return []
            
        commits = []
        for line in result.stdout.strip().split('\n'):
            if line:
                parts = line.split('|||')
                if len(parts) >= 4:
                    commits.append({
                        'hash': parts[0],
                        'message': parts[1],
                        'author': parts[2],
                        'date': parts[3]
                    })
        return commits
    except subprocess.CalledProcessError as e:
        print(f"Error getting commits for file: {e}")
        return []


def is_git_lfs_pointer(content):
    """Check if content is a Git LFS pointer file."""
    if not content or len(content) > 1024:
        # LFS pointer files are small (typically < 200 bytes)
        return False
    try:
        text = content.decode('utf-8', errors='ignore')
        # LFS pointer files start with "version https://git-lfs.github.com/spec/v1"
        return text.startswith('version https://git-lfs.github.com/spec/')
    except (UnicodeDecodeError, AttributeError):
        return False


def get_lfs_file_content(pointer_content):
    """Get actual file content from Git LFS pointer.
    
    Args:
        pointer_content: The LFS pointer file content (bytes)
    
    Returns:
        Actual file content, or None if LFS is not available or fetch fails
    """
    try:
        repo_path = get_repo_path()
        # Pass pointer content through git-lfs smudge filter
        smudge_result = subprocess.run(
            ['git', 'lfs', 'smudge'],
            input=pointer_content,
            cwd=repo_path,
            capture_output=True,
            check=True,
            timeout=60  # Reasonable timeout for LFS fetch
        )
        return smudge_result.stdout
    except FileNotFoundError:
        print("Warning: Git LFS is not installed. Cannot retrieve actual file content from LFS pointer.")
        return None
    except subprocess.TimeoutExpired:
        print("Warning: Git LFS fetch timed out.")
        return None
    except subprocess.CalledProcessError as e:
        print(f"Error getting LFS file content: {e}")
        return None


def get_file_content(commit_hash, file_path):
    """Get file content at a specific commit."""
    try:
        repo_path = get_repo_path()
        # Use a reasonable timeout for file retrieval
        result = subprocess.run(
            ['git', 'show', f'{commit_hash}:{file_path}'],
            cwd=repo_path,
            capture_output=True,
            check=True,
            timeout=60  # 1 minute timeout
        )
        content = result.stdout
        
        # Check if this is a Git LFS pointer file
        if is_git_lfs_pointer(content):
            print(f"Detected Git LFS pointer for {file_path}, fetching actual content...")
            lfs_content = get_lfs_file_content(content)
            if lfs_content:
                content = lfs_content
            else:
                print(f"Warning: Failed to fetch LFS content, using pointer file")
        
        return content
    except subprocess.TimeoutExpired:
        print(f"Timeout getting file content for {file_path}")
        return None
    except subprocess.CalledProcessError as e:
        print(f"Error getting file content: {e}")
        return None


def parse_excel_data(file_content, max_rows_per_sheet=100000):
    """Parse Excel file content and return data as dictionary.
    
    Args:
        file_content: Binary content of the Excel file
        max_rows_per_sheet: Maximum number of rows to read per sheet (to prevent memory issues)
    
    Returns:
        Dictionary with sheet names as keys and row data as values, or None on error
    """
    try:
        file_size_mb = len(file_content) / (1024 * 1024)
        logger.info(f"Parsing Excel file: {file_size_mb:.2f} MB")
        
        with BytesIO(file_content) as bio:
            # Try reading with pandas
            excel_data = {}
            xls = pd.ExcelFile(bio)
            
            for sheet_name in xls.sheet_names:
                try:
                    # Read sheet with row limit for large files using the ExcelFile object
                    df = pd.read_excel(xls, sheet_name=sheet_name, nrows=max_rows_per_sheet)
                    # Replace NaN values with None to ensure JSON serialization works
                    df = df.replace({pd.NA: None, float('nan'): None, float('inf'): None, float('-inf'): None})
                    # Also handle NaN using fillna
                    df = df.where(pd.notnull(df), None)
                    excel_data[sheet_name] = df.to_dict('records')
                    row_count = len(df)
                    logger.info(f"Parsed sheet '{sheet_name}': {row_count} rows, {len(df.columns) if not df.empty else 0} columns")
                    
                    # Note: We don't add a warning here because row_count_change comparison will detect truncation
                except Exception as e:
                    logger.error(f"Error parsing sheet '{sheet_name}': {e}")
                    # Continue with other sheets
                    excel_data[sheet_name] = []
            
            return excel_data
    except MemoryError as e:
        logger.error(f"Memory error parsing Excel (file too large): {e}")
        return None
    except Exception as e:
        logger.error(f"Error parsing Excel: {e}")
        import traceback
        traceback.print_exc()
        return None


def sample_large_file_content(content, max_sample_size=50000):
    """Sample content from a large file to enable comparison.
    
    Uses intelligent sampling to extract representative sections from large files
    while maintaining memory efficiency. For text files, samples from the beginning,
    middle, and end. Binary files are identified by MD5 hash for comparison.
    
    Args:
        content: Binary file content
        max_sample_size: Maximum number of bytes to sample from each section (default: 50KB)
    
    Returns:
        String containing either:
        - Full text content for small files
        - Sampled text with omission markers for large files
        - MD5 hash marker for binary files
        - Error message if sampling fails
    """
    try:
        # Try to decode as text
        try:
            text = content.decode('utf-8')
            
            # Check if decoded text is likely binary (contains null bytes or too many control chars)
            # Binary files often contain null bytes or excessive control characters
            null_count = text.count('\x00')
            control_chars = sum(1 for c in text if ord(c) < 32 and c not in '\n\r\t')
            
            # Use defined thresholds to detect binary content
            if len(text) > 0 and (null_count / len(text) > MAX_NULL_BYTE_RATIO or 
                                  control_chars / len(text) > MAX_CONTROL_CHAR_RATIO):
                file_hash = hashlib.md5(content).hexdigest()
                return f"<binary file: MD5={file_hash}>"
                
        except UnicodeDecodeError:
            # Not a text file, return hash for comparison
            file_hash = hashlib.md5(content).hexdigest()
            return f"<binary file: MD5={file_hash}>"
        
        # If file is small enough, return full content
        if len(text) <= max_sample_size * 3:
            return text
        
        # For large text files, sample from beginning, middle, and end
        lines = text.split('\n')
        total_lines = len(lines)
        
        # Calculate sample size (aim for ~1000 lines from each section)
        lines_per_section = min(1000, total_lines // 4)
        
        # Sample from beginning
        beginning_lines = lines[:lines_per_section]
        
        # Sample from middle
        middle_start = (total_lines // 2) - (lines_per_section // 2)
        middle_lines = lines[middle_start:middle_start + lines_per_section]
        
        # Sample from end
        end_lines = lines[-lines_per_section:]
        
        # Calculate omitted lines for each gap
        # Gap 1: between beginning and middle
        gap1_omitted = middle_start - lines_per_section
        # Gap 2: between middle and end
        middle_end = middle_start + lines_per_section
        end_start = total_lines - lines_per_section
        gap2_omitted = end_start - middle_end
        
        # Combine samples with accurate omission markers
        sampled_content = (
            '\n'.join(beginning_lines) + '\n' +
            (f'\n[... {gap1_omitted} lines omitted ...]\n\n' if gap1_omitted > 0 else '\n') +
            '\n'.join(middle_lines) + '\n' +
            (f'\n[... {gap2_omitted} lines omitted ...]\n\n' if gap2_omitted > 0 else '\n') +
            '\n'.join(end_lines)
        )
        
        return sampled_content
    except Exception as e:
        print(f"Error sampling file content: {e}")
        return f"<unable to sample: {str(e)}>"


def parse_zip_data(file_content, max_file_size_for_content=10*1024*1024, max_file_size_for_sampling=1024*1024*1024):
    """Parse ZIP file content and return list of files.
    
    Args:
        file_content: Binary content of the ZIP file
        max_file_size_for_content: Maximum size of individual files to read full content (default 10MB)
        max_file_size_for_sampling: Maximum size for sampling large files (default 1GB)
    
    Returns:
        List of file information dictionaries, or None on error
    """
    try:
        file_size_mb = len(file_content) / (1024 * 1024)
        print(f"Parsing ZIP file: {file_size_mb:.2f} MB")
        
        with BytesIO(file_content) as bio:
            with zipfile.ZipFile(bio, 'r') as zip_ref:
                file_list = []
                total_files = len(zip_ref.filelist)
                print(f"ZIP contains {total_files} files/directories")
                
                for idx, file_info in enumerate(zip_ref.filelist):
                    file_data = {
                        'filename': file_info.filename,
                        'size': file_info.file_size,
                        'compressed_size': file_info.compress_size,
                        'is_dir': file_info.is_dir()
                    }
                    
                    # Skip directories
                    if file_info.is_dir():
                        file_list.append(file_data)
                        continue
                    
                    # For small files, read full content
                    if file_info.file_size < max_file_size_for_content:
                        try:
                            content = zip_ref.read(file_info.filename)
                            # Try to decode as text, use consistent binary marker
                            try:
                                file_data['content'] = content.decode('utf-8')
                            except UnicodeDecodeError:
                                # Use MD5 hash for binary files to enable comparison
                                file_hash = hashlib.md5(content).hexdigest()
                                file_data['content'] = f"<binary file: MD5={file_hash}>"
                        except (zipfile.BadZipFile, KeyError, PermissionError) as e:
                            file_data['content'] = f"<unable to read: {str(e)}>"
                    # For large files but within sampling limit, sample the content
                    elif file_info.file_size < max_file_size_for_sampling:
                        try:
                            print(f"Sampling large file '{file_info.filename}' ({file_info.file_size / (1024*1024):.2f} MB)")
                            content = zip_ref.read(file_info.filename)
                            sampled = sample_large_file_content(content)
                            file_data['content'] = sampled
                            file_data['is_sampled'] = True
                            file_data['total_size'] = file_info.file_size
                        except (zipfile.BadZipFile, KeyError, PermissionError, MemoryError) as e:
                            file_data['content'] = f"<unable to read: {str(e)}>"
                    else:
                        # File too large even for sampling
                        file_data['content'] = f"<file too large: {file_info.file_size} bytes>"
                    
                    file_list.append(file_data)
                
                return file_list
    except zipfile.BadZipFile as e:
        print(f"Invalid ZIP file: {e}")
        return None
    except MemoryError as e:
        print(f"Memory error parsing ZIP (file too large): {e}")
        return None
    except Exception as e:
        print(f"Error parsing ZIP: {e}")
        import traceback
        traceback.print_exc()
        return None


def compare_excel_data(data1, data2, filename=''):
    """Compare two Excel data structures and return differences - Table view with cell-level data."""
    differences = []
    
    # Get all sheet names from both files
    sheets1 = set(data1.keys()) if data1 else set()
    sheets2 = set(data2.keys()) if data2 else set()
    
    # Sheets only in first commit (removed)
    for sheet in sheets1 - sheets2:
        rows = data1[sheet]
        # Get column names from the data
        columns = []
        if rows and len(rows) > 0:
            columns = list(rows[0].keys())
        
        differences.append({
            'type': 'sheet_removed',
            'sheet': sheet,
            'filename': filename,
            'columns': columns,
            'rows': rows,
            'row_count': len(rows),
            'message': f"Sheet '{sheet}' was removed"
        })
    
    # Sheets only in second commit (added)
    for sheet in sheets2 - sheets1:
        rows = data2[sheet]
        # Get column names from the data
        columns = []
        if rows and len(rows) > 0:
            columns = list(rows[0].keys())
        
        differences.append({
            'type': 'sheet_added',
            'sheet': sheet,
            'filename': filename,
            'columns': columns,
            'rows': rows,
            'row_count': len(rows),
            'message': f"Sheet '{sheet}' was added"
        })
    
    # Compare common sheets - Table view with row-level comparison
    for sheet in sheets1 & sheets2:
        rows1 = data1[sheet]
        rows2 = data2[sheet]
        
        # Check for row count differences (helps detect truncation for large files)
        row_count1 = len(rows1)
        row_count2 = len(rows2)
        if row_count1 != row_count2:
            differences.append({
                'type': 'row_count_change',
                'sheet': sheet,
                'old_count': row_count1,
                'new_count': row_count2,
                'message': f"Sheet '{sheet}': Row count changed from {row_count1} to {row_count2}"
            })
        
        # Get column names preserving order from the Excel file
        # Use the first non-empty row to determine column order
        all_cols = []
        cols_seen = set()
        
        # Get columns from first version in their original order
        if rows1 and len(rows1) > 0:
            for col in rows1[0].keys():
                if col not in cols_seen:
                    all_cols.append(col)
                    cols_seen.add(col)
        
        # Add any new columns from second version at the end
        if rows2 and len(rows2) > 0:
            for col in rows2[0].keys():
                if col not in cols_seen:
                    all_cols.append(col)
                    cols_seen.add(col)
        
        # Convert rows to CSV-like format for comparison (internal use only)
        def row_to_csv(row, cols):
            """Convert a row dict to CSV string with column values"""
            values = []
            for col in cols:
                val = row.get(col)
                if pd.isna(val):
                    values.append('')
                else:
                    # Quote values that contain commas
                    val_str = str(val)
                    if ',' in val_str:
                        values.append(f'"{val_str}"')
                    else:
                        values.append(val_str)
            return ','.join(values)
        
        # Get cell values as a list
        def row_to_cells(row, cols):
            """Convert a row dict to list of cell values"""
            cells = []
            for col in cols:
                val = row.get(col)
                if pd.isna(val):
                    cells.append('')
                else:
                    cells.append(str(val))
            return cells
        
        # Create CSV lines for each row (for comparison)
        csv_lines1 = []
        csv_lines2 = []
        
        for i, row in enumerate(rows1):
            csv_lines1.append(row_to_csv(row, all_cols))
        
        for i, row in enumerate(rows2):
            csv_lines2.append(row_to_csv(row, all_cols))
        
        # Use difflib to compare lines
        import difflib
        differ = difflib.SequenceMatcher(None, csv_lines1, csv_lines2)
        
        # Generate line-by-line diff with row numbers
        diff_lines = []
        
        for tag, i1, i2, j1, j2 in differ.get_opcodes():
            if tag == 'equal':
                # Lines are the same - optionally include context
                continue  # Skip unchanged lines for now
            elif tag == 'delete':
                # Lines only in first version (removed rows)
                for i in range(i1, i2):
                    diff_lines.append({
                        'type': 'removed',
                        'old_line_num': i + 1,
                        'new_line_num': None,
                        'content': csv_lines1[i],
                        'cells': row_to_cells(rows1[i], all_cols)
                    })
            elif tag == 'insert':
                # Lines only in second version (added rows)
                for j in range(j1, j2):
                    diff_lines.append({
                        'type': 'added',
                        'old_line_num': None,
                        'new_line_num': j + 1,
                        'content': csv_lines2[j],
                        'cells': row_to_cells(rows2[j], all_cols)
                    })
            elif tag == 'replace':
                # Lines changed - show old and new
                for i in range(i1, i2):
                    diff_lines.append({
                        'type': 'removed',
                        'old_line_num': i + 1,
                        'new_line_num': None,
                        'content': csv_lines1[i],
                        'cells': row_to_cells(rows1[i], all_cols)
                    })
                for j in range(j1, j2):
                    diff_lines.append({
                        'type': 'added',
                        'old_line_num': None,
                        'new_line_num': j + 1,
                        'content': csv_lines2[j],
                        'cells': row_to_cells(rows2[j], all_cols)
                    })
        
        # Add the table-style diff for this sheet if there are changes
        if diff_lines:
            differences.append({
                'type': 'sheet_table_diff',
                'sheet': sheet,
                'filename': filename,
                'columns': all_cols,
                'diff_lines': diff_lines,
                'message': f"Sheet '{sheet}': {len(diff_lines)} line(s) changed"
            })
    
    return differences


def is_json_file(filename):
    """Check if a file is a JSON file based on extension."""
    return filename.lower().endswith('.json')


def try_parse_json(content):
    """Try to parse content as JSON. Returns (success, parsed_json_or_error)."""
    if not content or not isinstance(content, str):
        return False, "Empty or invalid content"
    
    try:
        parsed = json.loads(content)
        return True, parsed
    except json.JSONDecodeError as e:
        return False, f"JSON parse error: {str(e)}"
    except Exception as e:
        return False, f"Error: {str(e)}"


def get_json_path_str(path):
    """Convert a path list to a string representation."""
    if not path:
        return "root"
    result = ""
    for part in path:
        if isinstance(part, int):
            result += f"[{part}]"
        else:
            if result:
                result += f".{part}"
            else:
                result = part
    return result


def compare_json_objects(obj1, obj2, path=None):
    """Recursively compare two JSON objects and return differences.
    
    Returns a list of change dictionaries with:
    - path: The JSON path to the change
    - type: 'added', 'removed', 'changed'
    - old_value: The old value (for removed/changed)
    - new_value: The new value (for added/changed)
    """
    if path is None:
        path = []
    
    changes = []
    
    # Handle None/null cases
    if obj1 is None and obj2 is None:
        return changes
    if obj1 is None:
        changes.append({
            'path': get_json_path_str(path),
            'type': 'added',
            'new_value': obj2
        })
        return changes
    if obj2 is None:
        changes.append({
            'path': get_json_path_str(path),
            'type': 'removed',
            'old_value': obj1
        })
        return changes
    
    # If types are different, treat as changed
    if type(obj1) != type(obj2):
        changes.append({
            'path': get_json_path_str(path),
            'type': 'changed',
            'old_value': obj1,
            'new_value': obj2
        })
        return changes
    
    # Compare dictionaries
    if isinstance(obj1, dict):
        all_keys = set(obj1.keys()) | set(obj2.keys())
        for key in sorted(all_keys):
            new_path = path + [key]
            if key in obj1 and key not in obj2:
                changes.append({
                    'path': get_json_path_str(new_path),
                    'type': 'removed',
                    'old_value': obj1[key]
                })
            elif key not in obj1 and key in obj2:
                changes.append({
                    'path': get_json_path_str(new_path),
                    'type': 'added',
                    'new_value': obj2[key]
                })
            else:
                # Key exists in both - recurse
                changes.extend(compare_json_objects(obj1[key], obj2[key], new_path))
    
    # Compare lists
    elif isinstance(obj1, list):
        max_len = max(len(obj1), len(obj2))
        for i in range(max_len):
            new_path = path + [i]
            if i >= len(obj1):
                changes.append({
                    'path': get_json_path_str(new_path),
                    'type': 'added',
                    'new_value': obj2[i]
                })
            elif i >= len(obj2):
                changes.append({
                    'path': get_json_path_str(new_path),
                    'type': 'removed',
                    'old_value': obj1[i]
                })
            else:
                # Both have element at index i - recurse
                changes.extend(compare_json_objects(obj1[i], obj2[i], new_path))
    
    # Compare primitives
    else:
        if obj1 != obj2:
            changes.append({
                'path': get_json_path_str(path),
                'type': 'changed',
                'old_value': obj1,
                'new_value': obj2
            })
    
    return changes


def format_json_value(value, max_length=100):
    """Format a JSON value for display, truncating if necessary."""
    if value is None:
        return "null"
    
    json_str = json.dumps(value, ensure_ascii=False)
    
    # If it's a simple value or short, return as is
    if len(json_str) <= max_length:
        return json_str
    
    # For complex values, show truncated version
    if isinstance(value, dict):
        num_keys = len(value)
        return f"{{...}} ({num_keys} keys)"
    elif isinstance(value, list):
        num_items = len(value)
        return f"[...] ({num_items} items)"
    else:
        return json_str[:max_length] + "..."


def perform_line_by_line_diff(content1, content2, filename, is_sampled=False, file1_size=None, file2_size=None):
    """Perform line-by-line diff comparison between two text contents.
    
    Args:
        content1: First content string
        content2: Second content string
        filename: Name of the file being compared
        is_sampled: Whether the content is sampled
        file1_size: Size of first file (optional)
        file2_size: Size of second file (optional)
        
    Returns:
        List of line change dictionaries
    """
    lines1 = content1.splitlines(keepends=False)
    lines2 = content2.splitlines(keepends=False)
    
    # Use unified diff with context lines
    differ = difflib.unified_diff(
        lines1, lines2,
        fromfile=f'{filename} (old)',
        tofile=f'{filename} (new)',
        lineterm='',
        n=3  # number of context lines
    )
    
    # Parse the diff output
    line_changes = []
    old_line_num = 0
    new_line_num = 0
    in_hunk = False
    
    for line in differ:
        if line.startswith('---') or line.startswith('+++'):
            continue
        elif line.startswith('@@'):
            # Parse line numbers from hunk header
            match = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', line)
            if match:
                old_line_num = int(match.group(1))
                new_line_num = int(match.group(3))
                in_hunk = True
        elif in_hunk:
            if line.startswith('-'):
                line_changes.append({
                    'type': 'removed',
                    'old_line_num': old_line_num,
                    'new_line_num': None,
                    'content': line[1:]
                })
                old_line_num += 1
            elif line.startswith('+'):
                line_changes.append({
                    'type': 'added',
                    'old_line_num': None,
                    'new_line_num': new_line_num,
                    'content': line[1:]
                })
                new_line_num += 1
            elif line.startswith(' '):
                # Context line (unchanged)
                line_changes.append({
                    'type': 'context',
                    'old_line_num': old_line_num,
                    'new_line_num': new_line_num,
                    'content': line[1:]
                })
                old_line_num += 1
                new_line_num += 1
    
    return line_changes


def compare_zip_data(data1, data2):
    """Compare two ZIP file structures and return differences."""
    differences = []
    
    # Create dictionaries for easier comparison
    files1 = {f['filename']: f for f in data1} if data1 else {}
    files2 = {f['filename']: f for f in data2} if data2 else {}
    
    # Files only in first commit (removed)
    for filename in set(files1.keys()) - set(files2.keys()):
        file1 = files1[filename]
        # Show content of removed files
        if 'content' in file1 and file1['content']:
            lines = file1['content'].splitlines(keepends=False)
            line_changes = []
            for i, line in enumerate(lines, start=1):
                line_changes.append({
                    'type': 'removed',
                    'old_line_num': i,
                    'new_line_num': None,
                    'content': line
                })
            differences.append({
                'type': 'content_change_lines',
                'filename': filename,
                'line_changes': line_changes,
                'message': f"File '{filename}' was removed from ZIP"
            })
        else:
            differences.append({
                'type': 'file_removed',
                'filename': filename,
                'message': f"File '{filename}' was removed from ZIP"
            })
    
    # Files only in second commit (added)
    for filename in set(files2.keys()) - set(files1.keys()):
        file2 = files2[filename]
        # Show content of added files
        if 'content' in file2 and file2['content']:
            lines = file2['content'].splitlines(keepends=False)
            line_changes = []
            for i, line in enumerate(lines, start=1):
                line_changes.append({
                    'type': 'added',
                    'old_line_num': None,
                    'new_line_num': i,
                    'content': line
                })
            differences.append({
                'type': 'content_change_lines',
                'filename': filename,
                'line_changes': line_changes,
                'message': f"File '{filename}' was added to ZIP"
            })
        else:
            differences.append({
                'type': 'file_added',
                'filename': filename,
                'message': f"File '{filename}' was added to ZIP"
            })
    
    # Compare common files
    for filename in set(files1.keys()) & set(files2.keys()):
        file1 = files1[filename]
        file2 = files2[filename]
        
        # Check for size differences
        size_changed = file1['size'] != file2['size']
        
        # Compare content if available
        content1 = file1.get('content', '')
        content2 = file2.get('content', '')
        
        # Check if either is sampled
        is_sampled1 = file1.get('is_sampled', False)
        is_sampled2 = file2.get('is_sampled', False)
        is_sampled = is_sampled1 or is_sampled2
        
        # Check if either content indicates a large/binary file (starts with our markers)
        is_special_marker1 = content1.startswith(('<binary data:', '<file too large:', '<unable to read:'))
        is_special_marker2 = content2.startswith(('<binary data:', '<file too large:', '<unable to read:'))
        
        # Check if it's a binary file marker (MD5 hash comparison)
        is_binary1 = content1.startswith('<binary file: MD5=')
        is_binary2 = content2.startswith('<binary file: MD5=')
        
        if is_binary1 and is_binary2:
            # Compare binary files by hash
            if content1 != content2:
                differences.append({
                    'type': 'file_size_change',
                    'filename': filename,
                    'old_size': file1['size'],
                    'new_size': file2['size'],
                    'message': f"File '{filename}': Binary content changed (Size: {file1['size']:,} → {file2['size']:,} bytes)"
                })
        elif is_special_marker1 or is_special_marker2:
            # For files that are too large or unable to read, report size differences
            if size_changed:
                differences.append({
                    'type': 'file_size_change',
                    'filename': filename,
                    'old_size': file1['size'],
                    'new_size': file2['size'],
                    'message': f"File '{filename}': Size changed from {file1['size']:,} bytes to {file2['size']:,} bytes"
                })
        elif content1 is not None and content2 is not None and (content1 or content2):
            # Both have readable content - check if it's JSON first
            if content1 != content2:
                # Check if this is a JSON file and both contents are valid JSON
                if is_json_file(filename) and not is_sampled:
                    success1, json_obj1 = try_parse_json(content1)
                    success2, json_obj2 = try_parse_json(content2)
                    
                    if success1 and success2:
                        # Both are valid JSON - do semantic comparison
                        json_changes = compare_json_objects(json_obj1, json_obj2)
                        
                        if json_changes:
                            # Convert JSON changes to line-based format for display
                            line_changes = []
                            for idx, change in enumerate(json_changes, start=1):
                                change_type = change['type']
                                path = change['path']
                                
                                if change_type == 'added':
                                    # Highlight complete value for added fields
                                    value_str = format_json_value(change['new_value'])
                                    content = f"{path}: {value_str}"
                                    line_changes.append({
                                        'type': 'added',
                                        'old_line_num': None,
                                        'new_line_num': idx,
                                        'content': content,
                                        'highlight_full_value': True,
                                        'value_start': len(path) + 2  # After "path: "
                                    })
                                elif change_type == 'removed':
                                    # Highlight complete value for removed fields
                                    value_str = format_json_value(change['old_value'])
                                    content = f"{path}: {value_str}"
                                    line_changes.append({
                                        'type': 'removed',
                                        'old_line_num': idx,
                                        'new_line_num': None,
                                        'content': content,
                                        'highlight_full_value': True,
                                        'value_start': len(path) + 2  # After "path: "
                                    })
                                elif change_type == 'changed':
                                    # For changed values, highlight the complete value on both sides
                                    old_value_str = format_json_value(change['old_value'])
                                    new_value_str = format_json_value(change['new_value'])
                                    old_content = f"{path}: {old_value_str}"
                                    new_content = f"{path}: {new_value_str}"
                                    line_changes.append({
                                        'type': 'removed',
                                        'old_line_num': idx,
                                        'new_line_num': None,
                                        'content': old_content,
                                        'highlight_full_value': True,
                                        'value_start': len(path) + 2  # After "path: "
                                    })
                                    line_changes.append({
                                        'type': 'added',
                                        'old_line_num': None,
                                        'new_line_num': idx,
                                        'content': new_content,
                                        'highlight_full_value': True,
                                        'value_start': len(path) + 2  # After "path: "
                                    })
                            
                            differences.append({
                                'type': 'content_change_lines',
                                'filename': filename,
                                'line_changes': line_changes,
                                'is_sampled': is_sampled,
                                'old_size': file1['size'],
                                'new_size': file2['size'],
                                'message': f"File '{filename}': JSON content changed ({len(json_changes)} changes)",
                                'is_json': True
                            })
                        # If no JSON changes detected, files are semantically identical
                    else:
                        # One or both failed to parse as JSON - fall back to line diff
                        # Add a note about JSON parse error
                        parse_error_msg = []
                        if not success1:
                            parse_error_msg.append(f"Old version: {json_obj1}")
                        if not success2:
                            parse_error_msg.append(f"New version: {json_obj2}")
                        
                        # Do regular line-by-line comparison using helper function
                        line_changes = perform_line_by_line_diff(
                            content1, content2, filename, is_sampled, 
                            file1['size'], file2['size']
                        )
                        
                        error_note = " (Note: " + ", ".join(parse_error_msg) + ")" if parse_error_msg else ""
                        differences.append({
                            'type': 'content_change_lines',
                            'filename': filename,
                            'line_changes': line_changes,
                            'is_sampled': is_sampled,
                            'old_size': file1['size'],
                            'new_size': file2['size'],
                            'message': f"File '{filename}': Content changed{error_note}"
                        })
                else:
                    # Not JSON or is sampled - do regular line-by-line comparison
                    line_changes = perform_line_by_line_diff(
                        content1, content2, filename, is_sampled,
                        file1['size'], file2['size']
                    )
                    
                    # Create appropriate message based on sampling
                    if is_sampled:
                        size_info = f"{file1['size']:,} → {file2['size']:,} bytes"
                        message = f"File '{filename}': Content changed (sampled comparison, sizes: {size_info})"
                    else:
                        message = f"File '{filename}': Content changed"
                    
                    differences.append({
                        'type': 'content_change_lines',
                        'filename': filename,
                        'line_changes': line_changes,
                        'is_sampled': is_sampled,
                        'old_size': file1['size'],
                        'new_size': file2['size'],
                        'message': message
                    })
        elif size_changed:
            # Size changed but no content available for comparison
            differences.append({
                'type': 'file_size_change',
                'filename': filename,
                'old_size': file1['size'],
                'new_size': file2['size'],
                'message': f"File '{filename}': Size changed from {file1['size']:,} bytes to {file2['size']:,} bytes"
            })
    
    return differences


@app.route('/')
def index():
    """Main page."""
    return render_template('index.html')


@app.route('/api/config/github', methods=['POST'])
def api_config_github():
    """Configure GitHub repository connection."""
    data = request.json
    github_url = data.get('github_url', '').strip()
    token = data.get('token', '').strip()
    
    if not github_url:
        return jsonify({'error': 'GitHub URL is required'}), 400
    
    # Validate URL format
    if not github_url.startswith('https://'):
        return jsonify({'error': 'Please provide a valid HTTPS URL'}), 400
    
    # Clone or update the repository
    repo_path, error = clone_or_update_repo(github_url, token if token else None)
    
    if error:
        return jsonify({'error': error}), 500
    
    # Store repo path in session
    session['repo_path'] = repo_path
    session['github_url'] = github_url
    
    return jsonify({
        'success': True,
        'message': 'Repository connected successfully',
        'repo_path': repo_path
    })


@app.route('/api/config/reset', methods=['POST'])
def api_config_reset():
    """Reset to local repository."""
    session.pop('repo_path', None)
    session.pop('github_url', None)
    session.pop('storage_mode', None)
    session.pop('gcs_bucket_name', None)
    session.pop('gcs_prefix', None)
    
    return jsonify({
        'success': True,
        'message': 'Reset to local repository'
    })


@app.route('/api/config/refresh', methods=['POST'])
def api_config_refresh():
    """Refresh repository to fetch latest commits."""
    repo_path = get_repo_path()
    is_github = repo_path != DEFAULT_REPO_PATH
    
    if not is_github:
        # For local repository, no fetch needed - just reload
        return jsonify({
            'success': True,
            'message': 'Local repository refreshed'
        })
    
    # For GitHub repository, fetch latest commits
    try:
        github_url = session.get('github_url', '')
        if not github_url:
            return jsonify({'error': 'No GitHub repository configured'}), 400
        
        # Fetch updates from remote
        result = subprocess.run(
            ['git', 'fetch', '--all'],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode != 0:
            return jsonify({'error': f'Failed to fetch updates: {result.stderr}'}), 500
        
        # Note: We only fetch, not pull, to avoid merge conflicts
        # The fetched commits will be visible through git log
        return jsonify({
            'success': True,
            'message': 'Repository refreshed successfully. New commits fetched from remote.'
        })
    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Refresh timed out. Please check your network connection.'}), 500
    except Exception as e:
        return jsonify({'error': f'Failed to refresh: {str(e)}'}), 500


@app.route('/api/config/gcs', methods=['POST'])
def api_config_gcs():
    """Configure GCS bucket connection."""
    data = request.json
    bucket_name = data.get('bucket_name', '').strip()
    prefix = data.get('prefix', '').strip()
    
    if not bucket_name:
        return jsonify({'error': 'Bucket name is required'}), 400
    
    # Connect to GCS bucket
    result, error = connect_to_gcs_bucket(bucket_name, prefix)
    
    if error:
        return jsonify({'error': error}), 500
    
    return jsonify({
        'success': True,
        'message': f'Connected to GCS bucket: {bucket_name}',
        'bucket_name': bucket_name,
        'prefix': prefix
    })


@app.route('/api/config/status')
def api_config_status():
    """Get current configuration status."""
    storage_mode = get_storage_mode()
    
    if storage_mode == 'gcs':
        gcs_config = get_gcs_config()
        return jsonify({
            'storage_mode': 'gcs',
            'is_configured': True,
            'bucket_name': gcs_config['bucket_name'],
            'prefix': gcs_config['prefix'],
            'using_local': False
        })
    else:
        repo_path = get_repo_path()
        is_github = repo_path != DEFAULT_REPO_PATH
        
        return jsonify({
            'storage_mode': 'github' if is_github else 'git',
            'is_configured': is_github,
            'repo_path': repo_path,
            'github_url': session.get('github_url', ''),
            'using_local': not is_github
        })


@app.route('/api/branches')
def api_branches():
    """API endpoint to get all branches."""
    branches = get_branches()
    return jsonify(branches)


@app.route('/api/commits')
def api_commits():
    """API endpoint to get commits, optionally filtered by branch and/or file."""
    branch = request.args.get('branch')
    file_path = request.args.get('file')
    
    if branch and file_path:
        # Get commits for a specific file in a branch
        commits = get_commits_for_file(branch, file_path)
    elif branch:
        # Get commits for a specific branch
        commits = get_commits_for_branch(branch)
    else:
        # Get all commits
        commits = get_all_commits()
    return jsonify(commits)


@app.route('/api/files')
def api_files():
    """API endpoint to get files, optionally filtered by branch or commit.
    
    In GCS mode, returns only Excel files (.xlsx, .xls) as per requirements.
    In Git/GitHub mode, returns all supported file types (.xlsx, .xls, .zip).
    """
    storage_mode = get_storage_mode()
    
    if storage_mode == 'gcs':
        # GCS mode: return list of Excel files only (.xlsx, .xls) as specified in requirements
        gcs_config = get_gcs_config()
        files = get_gcs_files(gcs_config['bucket_name'], gcs_config['prefix'], file_extensions=('.xlsx', '.xls'))
        return jsonify(files)
    else:
        # Git/GitHub mode
        branch = request.args.get('branch')
        commit_hash = request.args.get('commit')
        
        if branch:
            # Get files for a specific branch
            files = get_files_for_branch(branch)
        elif commit_hash:
            # Get files at a specific commit
            files = get_files_at_commit(commit_hash)
        else:
            # Get files from all commits (legacy behavior)
            commits = get_all_commits()
            all_files = set()
            for commit in commits[:10]:  # Check last 10 commits
                files = get_files_at_commit(commit['hash'])
                all_files.update(files)
            return jsonify(list(all_files))
        
        return jsonify(files)


@app.route('/api/gcs/versions')
def api_gcs_versions():
    """API endpoint to get all versions of a file from GCS."""
    file_path = request.args.get('file')
    
    if not file_path:
        return jsonify({'error': 'File path is required'}), 400
    
    storage_mode = get_storage_mode()
    if storage_mode != 'gcs':
        return jsonify({'error': 'Not in GCS mode'}), 400
    
    gcs_config = get_gcs_config()
    versions = get_gcs_file_versions(gcs_config['bucket_name'], file_path, gcs_config['prefix'])
    
    return jsonify(versions)


@app.route('/api/compare', methods=['POST'])
def api_compare():
    """API endpoint to compare a file between two commits or GCS versions."""
    data = request.json
    commit1 = data.get('commit1')
    commit2 = data.get('commit2')
    file_path = data.get('file')
    
    logger.info(f"Compare request: file={file_path}, version1={commit1}, version2={commit2}")
    
    if not all([commit1, commit2, file_path]):
        logger.error("Missing required parameters for compare")
        return jsonify({'error': 'Missing required parameters'}), 400
    
    storage_mode = get_storage_mode()
    logger.info(f"Storage mode: {storage_mode}")
    
    if storage_mode == 'gcs':
        # GCS mode: download file versions by generation
        gcs_config = get_gcs_config()
        logger.info(f"Downloading GCS files from bucket: {gcs_config['bucket_name']}, prefix: {gcs_config['prefix']}")
        content1 = download_gcs_file_version(gcs_config['bucket_name'], file_path, commit1, gcs_config['prefix'])
        content2 = download_gcs_file_version(gcs_config['bucket_name'], file_path, commit2, gcs_config['prefix'])
    else:
        # Git/GitHub mode: get file content from commits
        logger.info(f"Getting file content from commits")
        content1 = get_file_content(commit1, file_path)
        content2 = get_file_content(commit2, file_path)
    
    if content1 is None:
        logger.error(f"File not found in version {commit1}")
        return jsonify({'error': f'File not found in version {commit1}'}), 404
    if content2 is None:
        logger.error(f"File not found in version {commit2}")
        return jsonify({'error': f'File not found in version {commit2}'}), 404
    
    # Check file sizes
    size1_mb = len(content1) / (1024 * 1024)
    size2_mb = len(content2) / (1024 * 1024)
    logger.info(f"Comparing {file_path}: {size1_mb:.2f} MB vs {size2_mb:.2f} MB")
    
    # Determine file type and parse accordingly
    file_lower = file_path.lower()
    differences = []
    
    if file_lower.endswith(('.xlsx', '.xls')):
        # Parse Excel files
        logger.info(f"Parsing Excel files...")
        data1 = parse_excel_data(content1)
        data2 = parse_excel_data(content2)
        
        if data1 is None or data2 is None:
            logger.error("Failed to parse Excel files")
            return jsonify({
                'error': 'Failed to parse Excel file. The file may be too large or corrupted.',
                'size1_mb': round(size1_mb, 2),
                'size2_mb': round(size2_mb, 2)
            }), 500
        
        logger.info(f"Comparing Excel data...")
        differences = compare_excel_data(data1, data2, file_path)
        file_type = 'excel'
        
    elif file_lower.endswith('.zip'):
        # Parse ZIP files
        logger.info(f"Parsing ZIP files...")
        data1 = parse_zip_data(content1)
        data2 = parse_zip_data(content2)
        
        if data1 is None or data2 is None:
            logger.error("Failed to parse ZIP files")
            return jsonify({
                'error': 'Failed to parse ZIP file. The file may be too large or corrupted.',
                'size1_mb': round(size1_mb, 2),
                'size2_mb': round(size2_mb, 2)
            }), 500
        
        logger.info(f"Comparing ZIP data...")
        differences = compare_zip_data(data1, data2)
        file_type = 'zip'
    else:
        logger.error(f"Unsupported file type: {file_path}")
        return jsonify({'error': 'Unsupported file type'}), 400
    
    logger.info(f"Comparison complete: {len(differences)} differences found")
    
    # Sanitize differences to ensure JSON serialization works (remove NaN, Inf values)
    differences = sanitize_for_json(differences)
    
    return jsonify({
        'file_type': file_type,
        'differences': differences,
        'total_changes': len(differences),
        'size1_mb': round(size1_mb, 2),
        'size2_mb': round(size2_mb, 2)
    })


def format_excel_for_template(excel_dict):
    """Transform Excel data from parse_excel_data format to template-expected format.
    
    Converts from: {'Sheet1': [{'col1': 'val1', 'col2': 'val2'}, ...]}
    To: {'sheets': {'Sheet1': {'columns': ['col1', 'col2'], 'rows': [['val1', 'val2'], ...]}}}
    """
    formatted = {'sheets': {}}
    for sheet_name, records in excel_dict.items():
        if records and len(records) > 0:
            # Get columns from first record
            columns = list(records[0].keys())
            # Convert records to rows
            rows = [[record.get(col, '') for col in columns] for record in records]
            formatted['sheets'][sheet_name] = {
                'columns': columns,
                'rows': rows
            }
        else:
            # Empty sheet
            formatted['sheets'][sheet_name] = {
                'columns': [],
                'rows': []
            }
    return formatted


def build_cell_highlights(differences, excel_data):
    """Build a mapping of which cells have changes for highlighting in the template.
    
    Returns: Dictionary mapping sheet_name -> row_index -> col_index -> change_type
    """
    highlights = {}
    
    for diff in differences:
        if diff['type'] == 'sheet_table_diff':
            sheet_name = diff['sheet']
            columns = diff['columns']
            if sheet_name not in highlights:
                highlights[sheet_name] = {}
            
            # Group diff lines by their position to match removed/added pairs
            diff_lines = diff.get('diff_lines', [])
            
            # Separate removed and added lines
            removed_lines = {}  # old_line_num -> line
            added_lines = {}    # new_line_num -> line
            
            for line in diff_lines:
                if line['type'] == 'removed' and line['old_line_num']:
                    removed_lines[line['old_line_num']] = line
                elif line['type'] == 'added' and line['new_line_num']:
                    added_lines[line['new_line_num']] = line
            
            # Try to match removed and added lines that are replacements (row changes)
            # We'll use position-based matching for simplicity
            processed_added = set()
            
            for old_num, removed_line in sorted(removed_lines.items()):
                # Try to find a corresponding added line at a similar position
                # Look for added lines that haven't been processed yet
                matched = False
                for new_num, added_line in sorted(added_lines.items()):
                    if new_num in processed_added:
                        continue
                    
                    # If positions are close, treat as replacement
                    # This is a heuristic - in practice, consecutive removed/added often correspond
                    if abs(old_num - new_num) <= 2:  # Allow some position drift
                        # Cell-by-cell comparison
                        old_cells = removed_line.get('cells', [])
                        new_cells = added_line.get('cells', [])
                        
                        row_idx = new_num - 1  # 0-based index for the new row
                        if row_idx not in highlights[sheet_name]:
                            highlights[sheet_name][row_idx] = {}
                        
                        # Compare each cell
                        for col_idx in range(len(columns)):
                            old_val = old_cells[col_idx] if col_idx < len(old_cells) else ''
                            new_val = new_cells[col_idx] if col_idx < len(new_cells) else ''
                            
                            # Only highlight if the cell actually changed
                            if old_val != new_val:
                                highlights[sheet_name][row_idx][col_idx] = 'changed'
                        
                        processed_added.add(new_num)
                        matched = True
                        break
                
                # If no match found, the removed line is truly removed (not shown in new version)
            
            # Process any added lines that weren't matched (truly new rows)
            for new_num, added_line in added_lines.items():
                if new_num not in processed_added:
                    row_idx = new_num - 1
                    if row_idx not in highlights[sheet_name]:
                        highlights[sheet_name][row_idx] = {}
                    
                    # Highlight all cells in truly new rows
                    for col_idx in range(len(columns)):
                        highlights[sheet_name][row_idx][col_idx] = 'added'
    
    return highlights


@app.route('/preview/choose')
def preview_choose():
    """Show preview type choice page."""
    branch = request.args.get('branch')
    file_path = request.args.get('file')
    
    if not branch or not file_path:
        return jsonify({'error': 'Missing branch or file parameter'}), 400
    
    return render_template('preview_choose.html',
                         branch=branch,
                         file_path=file_path)


@app.route('/preview/file')
def preview_file():
    """Preview file at latest commit in a branch."""
    branch = request.args.get('branch')
    file_path = request.args.get('file')
    
    if not branch or not file_path:
        return jsonify({'error': 'Missing branch or file parameter'}), 400
    
    try:
        # Get the latest commit for the branch
        commits = get_commits_for_file(branch, file_path)
        if not commits:
            return jsonify({'error': 'No commits found for this file'}), 404
        
        latest_commit = commits[0]  # First commit is the latest
        
        # Get file content at latest commit
        content = get_file_content(latest_commit['hash'], file_path)
        if content is None:
            return jsonify({'error': 'File not found'}), 404
        
        # Parse and render based on file type
        file_lower = file_path.lower()
        
        if file_lower.endswith(('.xlsx', '.xls')):
            excel_data = parse_excel_data(content)
            if excel_data is None:
                return jsonify({'error': 'Failed to parse Excel file'}), 500
            # Format for template
            data = format_excel_for_template(excel_data)
            return render_template('preview_file.html', 
                                 file_path=file_path, 
                                 branch=branch,
                                 commit=latest_commit,
                                 file_type='excel',
                                 data=data)
        
        elif file_lower.endswith('.zip'):
            data = parse_zip_data(content)
            if data is None:
                return jsonify({'error': 'Failed to parse ZIP file'}), 500
            return render_template('preview_file.html',
                                 file_path=file_path,
                                 branch=branch,
                                 commit=latest_commit,
                                 file_type='zip',
                                 data=data)
        else:
            return jsonify({'error': 'Unsupported file type'}), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/preview/commit')
def preview_commit():
    """Preview file at specific commit with diff highlighting."""
    branch = request.args.get('branch')
    file_path = request.args.get('file')
    commit_hash = request.args.get('commit')
    
    if not branch or not file_path:
        return jsonify({'error': 'Missing branch or file parameter'}), 400
    
    try:
        # Get commits for file in branch
        commits = get_commits_for_file(branch, file_path)
        if not commits:
            return jsonify({'error': 'No commits found for this file'}), 404
        
        # If commit not specified, show commit selection page
        if not commit_hash:
            return render_template('preview_commit_select.html',
                                 file_path=file_path,
                                 branch=branch,
                                 commits=commits)
        
        # Find base commit (previous commit in the list)
        commit_index = next((i for i, c in enumerate(commits) if c['hash'] == commit_hash), None)
        if commit_index is None:
            return jsonify({'error': 'Commit not found'}), 404
        
        selected_commit = commits[commit_index]
        
        # Get base commit (next in list is previous in time)
        base_commit = commits[commit_index + 1] if commit_index + 1 < len(commits) else None
        
        # Get file content at both commits
        content_selected = get_file_content(commit_hash, file_path)
        if content_selected is None:
            return jsonify({'error': 'File not found in selected commit'}), 404
        
        content_base = None
        if base_commit:
            content_base = get_file_content(base_commit['hash'], file_path)
        
        # Parse and compare based on file type
        file_lower = file_path.lower()
        
        if file_lower.endswith(('.xlsx', '.xls')):
            excel_data_selected = parse_excel_data(content_selected)
            excel_data_base = parse_excel_data(content_base) if content_base else None
            
            if excel_data_selected is None:
                return jsonify({'error': 'Failed to parse Excel file'}), 500
            
            # Compare if base exists
            differences = []
            highlights = {}
            if excel_data_base:
                differences = compare_excel_data(excel_data_base, excel_data_selected, file_path)
                highlights = build_cell_highlights(differences, excel_data_selected)
            
            # Format for template
            data = format_excel_for_template(excel_data_selected)
            
            return render_template('preview_commit.html',
                                 file_path=file_path,
                                 branch=branch,
                                 selected_commit=selected_commit,
                                 base_commit=base_commit,
                                 file_type='excel',
                                 data=data,
                                 differences=differences,
                                 highlights=highlights)
        
        elif file_lower.endswith('.zip'):
            data_selected = parse_zip_data(content_selected)
            data_base = parse_zip_data(content_base) if content_base else None
            
            if data_selected is None:
                return jsonify({'error': 'Failed to parse ZIP file'}), 500
            
            # Compare if base exists
            differences = []
            if data_base:
                differences = compare_zip_data(data_base, data_selected)
            
            return render_template('preview_commit.html',
                                 file_path=file_path,
                                 branch=branch,
                                 selected_commit=selected_commit,
                                 base_commit=base_commit,
                                 file_type='zip',
                                 data=data_selected,
                                 differences=differences)
        else:
            return jsonify({'error': 'Unsupported file type'}), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    # Debug mode should only be enabled in development
    # Set debug=False or use environment variable for production
    debug_mode = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    app.run(debug=debug_mode, host='0.0.0.0', port=5001)
