# Excel and ZIP File Data Versioning

A Python web application that allows you to view and compare Excel and ZIP files between different versions. Supports Git repositories, GitHub, and Google Cloud Storage (GCS) buckets with versioning enabled.

## Features

- 📊 **Excel File Comparison**: Compare data in Excel files (.xlsx, .xls) across versions
- 📦 **ZIP File Comparison**: Compare contents and files within ZIP archives
- 🔍 **Detailed Difference View**: See exactly what changed between versions
- 🎨 **User-Friendly Interface**: Simple dropdown-based UI for selecting files and versions
- 📈 **Change Detection**: Identifies added, removed, and modified data
- 🔗 **GitHub Integration**: Connect to remote GitHub repositories using URL and token
- ☁️ **GCS Bucket Support**: Connect to Google Cloud Storage buckets with versioning enabled
- 🌐 **Multi-Source Support**: Works with local Git repositories, remote GitHub repos, and GCS buckets

## Prerequisites

### Option 1: Running with Docker (Recommended)
- Docker installed on your system
- Docker Compose (optional, for easier management)

### Option 2: Running with Python
- Python 3.8 or higher
- Git repository with Excel or ZIP files (for Git/GitHub mode)
- Google Cloud Storage bucket with versioning enabled (for GCS mode)
- pip (Python package manager)

### For GCS Bucket Mode:
- Google Cloud SDK (gcloud) installed and configured
- Authenticated with `gcloud auth login` and `gcloud auth application-default login`
- GCS bucket with versioning enabled
- Appropriate IAM permissions to read objects and list versions in the bucket

## Installation and Usage

### Option 1: Using Docker (Recommended)

Docker makes it easy to run the application without installing Python dependencies locally.

#### Quick Start with Docker Compose

1. Clone this repository:
```bash
git clone https://github.com/Sivareddy6244/excel_and_zip_flies_data_versioning.git
cd excel_and_zip_flies_data_versioning
```

2. Run with Docker Compose:
```bash
docker-compose up --build
```

3. Open your web browser and go to:
```
http://localhost:5001
```

4. To stop the application:
```bash
docker-compose down
```

#### Alternative: Using Docker Commands

1. Build the Docker image:
```bash
docker build -t excel-zip-versioning .
```

2. Run the container:
```bash
docker run -d -p 5001:5001 -v $(pwd):/app --name excel-versioning excel-zip-versioning
```

3. Access the application at `http://localhost:5001`

4. To stop and remove the container:
```bash
docker stop excel-versioning
docker rm excel-versioning
```

#### Docker Notes
- The application runs on port 5001 by default
- The current directory is mounted as a volume to `/app` in the container
- This allows the application to access your Git repository and files
- Environment variables can be configured in `docker-compose.yml`

### Option 2: Using Python Directly

1. Clone this repository:
```bash
git clone https://github.com/Sivareddy6244/excel_and_zip_flies_data_versioning.git
cd excel_and_zip_flies_data_versioning
```

2. Install required dependencies:
```bash
pip install -r requirements.txt
```

3. Run the Flask application:
```bash
python app.py
```

4. Open your web browser and go to:
```
http://localhost:5001
```

## How to Use the Web Interface

The application supports three storage modes:

1. **Local Repository Mode** (Default): Uses the local Git repository where the application is running
2. **GitHub Repository Mode**: Connect to any remote GitHub repository
3. **GCS Bucket Mode**: Connect to a Google Cloud Storage bucket with versioning enabled

### Connecting to a GitHub Repository

#### To Connect to a GitHub Repository:

1. Open the application at `http://localhost:5001`
2. In the **GitHub Repository Connection** section:
   - Enter the full GitHub repository URL (e.g., `https://github.com/username/repository`)
   - Optionally, provide a Personal Access Token for private repositories
   - Click **"Connect to GitHub"**
3. The application will clone the repository and load its commits and files

#### To Generate a GitHub Personal Access Token:

1. Visit [GitHub Settings > Tokens](https://github.com/settings/tokens)
2. Click "Generate new token (classic)"
3. Select scopes: `repo` (for private repos) or `public_repo` (for public repos only)
4. Copy the generated token and paste it in the application

### Connecting to a GCS Bucket

The GCS Bucket mode allows you to compare different versions of files stored in Google Cloud Storage.

#### Prerequisites:

1. **GCS Bucket with Versioning Enabled**:
   - Create a GCS bucket or use an existing one
   - Enable versioning on the bucket:
     ```bash
     gsutil versioning set on gs://your-bucket-name
     ```
   
2. **Authentication**:
   - The application uses Google Cloud Application Default Credentials
   - Authenticate using gcloud CLI before running the application:
     ```bash
     gcloud auth login
     gcloud auth application-default login
     ```
   - Alternatively, set the `GOOGLE_APPLICATION_CREDENTIALS` environment variable to point to a service account key file

#### To Connect to a GCS Bucket:

1. Open the application at `http://localhost:5001`
2. Click **"Switch to GCS Mode"** button
3. In the **GCS Bucket Connection** section:
   - Enter your GCS bucket name (e.g., `my-bucket-name`)
   - Optionally, enter a prefix/folder path (e.g., `excel-files/data`)
   - Click **"Connect to GCS Bucket"**
4. The application will verify access and load files from the bucket

#### Comparing File Versions in GCS:

1. **Select File**: Choose an Excel or ZIP file from the dropdown
2. **First Version (Older)**: Select the older version you want to compare from
3. **Second Version (Newer)**: Select the newer version you want to compare to
4. Click **"Compare Commits"** to see the differences

**Note**: The GCS bucket must have versioning enabled. If versioning is not enabled, the application will show an error message.

### Switching Between Modes

- Click **"Use Local Repository"** to switch back to local Git mode
- Click **"Switch to GitHub Mode"** to use GitHub mode
- Click **"Switch to GCS Mode"** to use GCS Bucket mode

### Comparing Files

1. **Select File**: Choose an Excel or ZIP file from the dropdown
2. **First Version/Commit**: Select the older version you want to compare from
3. **Second Version/Commit**: Select the newer version you want to compare to
4. Click **"Compare Commits"** to see the differences

## What Gets Compared

### Excel Files
- Sheet additions and removals
- Row count changes (helps detect truncation for large files)
- Cell-by-cell data changes
- Column additions and removals

### ZIP Files
- File additions and removals
- File size changes (especially useful for large files)
- Content changes (for text files up to 10MB)
- Directory structure changes

## Large File Support

This application has been optimized to handle large files (1GB+):

### Git LFS Support
- Automatically detects and retrieves Git LFS tracked files
- Fetches actual file content instead of LFS pointer files
- Note: Requires `git-lfs` to be installed for LFS file retrieval

### Memory-Efficient Processing
- **Excel Files**: Reads up to 100,000 rows per sheet to prevent memory issues
- **ZIP Files**: Reads content of individual files up to 10MB
- **Row Count Comparison**: Shows row count differences even when content is truncated

### Size-Based Comparison
- For very large files in ZIP archives, the tool compares file sizes instead of full content
- This ensures differences are detected even for files that are too large to compare line-by-line

### Performance Considerations
- File retrieval timeout: 60 seconds
- Suitable for files up to several GB when using Git LFS
- Row count changes and size changes are always detected, even for very large files

## Example Use Case

Imagine you have an Excel file `data.xlsx` in your repository:

1. **Commit 1**: You add the initial version with some data
2. **Commit 2**: You update some cells and add a new sheet
3. **Using this tool**: Select `data.xlsx`, choose Commit 1 and Commit 2, and see exactly what changed:
   - "Sheet 'Summary' was added"
   - "Sheet 'Data', Row 5, Column 'Price': '100' → '120'"
   - And more...

## API Endpoints

The application provides the following REST API endpoints:

### Git/GitHub Mode:
- `GET /api/commits` - Returns list of all commits
- `GET /api/files?commit=<hash>` - Returns Excel/ZIP files at a specific commit
- `GET /api/branches` - Returns list of branches

### GCS Mode:
- `GET /api/files` - Returns list of Excel/ZIP files in the bucket
- `GET /api/gcs/versions?file=<path>` - Returns all versions of a specific file

### Universal:
- `POST /api/compare` - Compares a file between two versions (works for both Git and GCS)
- `POST /api/config/github` - Connect to a GitHub repository
- `POST /api/config/gcs` - Connect to a GCS bucket
- `POST /api/config/reset` - Reset to local repository
- `GET /api/config/status` - Get current configuration status

## Troubleshooting

**No files showing up?**
- **Git/GitHub**: Make sure your repository contains .xlsx, .xls, or .zip files
- **Git/GitHub**: Ensure you have at least one commit in your repository
- **GCS**: Verify that the bucket contains files with supported extensions
- **GCS**: Check that you have permission to list objects in the bucket

**Comparison failing?**
- Verify that the selected file exists in both versions
- Check that the Excel file is not corrupted
- Ensure the ZIP file is valid

**GCS Connection Issues:**
- **Authentication Failed**: Run `gcloud auth login` and `gcloud auth application-default login`
- **Bucket Not Found**: Verify the bucket name is correct and you have access
- **Versioning Not Enabled**: Enable versioning with `gsutil versioning set on gs://your-bucket-name`
- **Permission Denied**: Ensure your account has `storage.objects.get` and `storage.objects.list` permissions
- **No Versions Showing**: The file may have been uploaded before versioning was enabled, or only has one version

**Large files not showing differences?**
- If you're using Git LFS, ensure `git-lfs` is installed: `git lfs install`
- Check that LFS tracked files are properly fetched
- For very large files, row count changes and file size changes will be shown even if full content comparison is not possible
- Excel files are limited to 100,000 rows per sheet; check row count differences to see if files are larger

**Performance issues with large files?**
- Files over 1GB may take longer to process
- Consider using Git LFS for better performance with large files (Git mode)
- The application automatically handles memory constraints by limiting row counts and file sizes
- **GCS**: Large file downloads may be slow depending on network speed

## Technical Details

- **Backend**: Flask (Python web framework)
- **Excel Processing**: pandas and openpyxl
- **ZIP Processing**: Built-in zipfile module
- **Version Control**: Git command-line interface
- **Frontend**: HTML, CSS, JavaScript (Vanilla)
- **Containerization**: Docker and Docker Compose

## Docker Configuration

The application includes the following Docker files:

- **Dockerfile**: Defines the container image with Python 3.11, Git, and all dependencies
- **docker-compose.yml**: Orchestrates the container setup with volume mounts and port mapping
- **.dockerignore**: Excludes unnecessary files from the Docker build context

### Environment Variables

You can configure the following environment variables:

- `FLASK_DEBUG`: Set to `true` for debug mode, `false` for production (default: `false`)
- Port mapping: Default is `5001:5001`, can be changed in `docker-compose.yml`

## License

This project is open source and available for educational and commercial use.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.