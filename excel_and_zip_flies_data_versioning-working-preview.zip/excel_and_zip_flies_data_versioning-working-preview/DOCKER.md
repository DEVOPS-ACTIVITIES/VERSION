# Docker Quick Start Guide

This guide provides quick instructions for running the Excel and ZIP File Data Versioning application using Docker.

## Prerequisites

- Docker installed on your system ([Download Docker](https://www.docker.com/get-started))
- Docker Compose (included with Docker Desktop)

## Quick Start

### Method 1: Using Docker Compose (Easiest)

1. **Navigate to the project directory:**
   ```bash
   cd excel_and_zip_flies_data_versioning
   ```

2. **Start the application:**
   ```bash
   docker-compose up --build
   ```
   
   The `--build` flag ensures the image is built with the latest code.

3. **Access the application:**
   Open your web browser and navigate to:
   ```
   http://localhost:5001
   ```

4. **Stop the application:**
   Press `Ctrl+C` in the terminal, or run:
   ```bash
   docker-compose down
   ```

### Method 2: Using Docker Commands

1. **Build the Docker image:**
   ```bash
   docker build -t excel-zip-versioning .
   ```

2. **Run the container:**
   ```bash
   docker run -d \
     -p 5001:5001 \
     -v $(pwd):/app \
     --name excel-versioning \
     excel-zip-versioning
   ```
   
   **For Windows PowerShell, use:**
   ```powershell
   docker run -d -p 5001:5001 -v ${PWD}:/app --name excel-versioning excel-zip-versioning
   ```

3. **View logs:**
   ```bash
   docker logs excel-versioning
   ```

4. **Stop and remove the container:**
   ```bash
   docker stop excel-versioning
   docker rm excel-versioning
   ```

## Docker Configuration Details

### Port Mapping
- The application runs on port **5001** inside the container
- It's mapped to port **5001** on your host machine
- To use a different port, modify the port mapping: `-p 8080:5001`

### Volume Mounting
- The current directory is mounted to `/app` in the container
- This allows the application to access your Git repository and files
- Any changes to files are reflected in real-time

### Environment Variables

You can set environment variables when running the container:

```bash
docker run -d \
  -p 5001:5001 \
  -v $(pwd):/app \
  -e FLASK_DEBUG=true \
  --name excel-versioning \
  excel-zip-versioning
```

Available environment variables:
- `FLASK_DEBUG`: Set to `true` for debug mode, `false` for production (default: `false`)

## Troubleshooting

### Port Already in Use
If port 5001 is already in use, change the port mapping:
```bash
docker run -d -p 5002:5001 -v $(pwd):/app --name excel-versioning excel-zip-versioning
```
Then access the application at `http://localhost:5002`

### Container Won't Start
Check the logs:
```bash
docker logs excel-versioning
```

### Rebuild After Code Changes
```bash
docker-compose down
docker-compose up --build
```

Or with Docker commands:
```bash
docker stop excel-versioning
docker rm excel-versioning
docker build -t excel-zip-versioning .
docker run -d -p 5001:5001 -v $(pwd):/app --name excel-versioning excel-zip-versioning
```

### Access Container Shell
To debug or inspect the container:
```bash
docker exec -it excel-versioning /bin/bash
```

## Docker Compose Configuration

The `docker-compose.yml` file includes:
- Automatic container restart (`restart: unless-stopped`)
- Network isolation with bridge driver
- Volume mounting for live code updates
- Environment variable configuration

## Production Deployment

For production deployment:

1. **Update docker-compose.yml:**
   - Set `FLASK_DEBUG=false`
   - Consider using a production WSGI server like Gunicorn
   - Add resource limits if needed

2. **Run in detached mode:**
   ```bash
   docker-compose up -d
   ```

3. **Monitor logs:**
   ```bash
   docker-compose logs -f
   ```

## Additional Commands

### View Running Containers
```bash
docker ps
```

### View All Containers (including stopped)
```bash
docker ps -a
```

### Remove All Stopped Containers
```bash
docker container prune
```

### Remove Unused Images
```bash
docker image prune
```

## Next Steps

After the application is running:
1. Open http://localhost:5001 in your browser
2. Select an Excel or ZIP file from the dropdown
3. Choose two commits to compare
4. Click "Compare Commits" to see the differences

For more information, see the main [README.md](README.md) file.
