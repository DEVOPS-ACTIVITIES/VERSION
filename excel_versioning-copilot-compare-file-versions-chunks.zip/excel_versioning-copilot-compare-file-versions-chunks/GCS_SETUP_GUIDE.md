# GCS Bucket Connection Guide

This guide will help you connect the Excel & ZIP File Data Versioning application to your Google Cloud Storage (GCS) bucket.

## Prerequisites

Before you begin, make sure you have:
1. A Google Cloud Platform (GCP) project
2. A GCS bucket created in your project
3. Access to Google Cloud Shell or a terminal with gcloud CLI installed

## Step-by-Step Setup

### Step 1: Create a GCS Bucket (if you don't have one)

1. Open Google Cloud Console: https://console.cloud.google.com
2. Navigate to **Cloud Storage** > **Buckets**
3. Click **CREATE BUCKET**
4. Enter a unique bucket name (e.g., `my-excel-files-bucket`)
5. Choose your preferred location and storage class
6. Click **CREATE**

### Step 2: Enable Versioning on Your Bucket

**Option A: Using Cloud Console**
1. Go to your bucket in the Cloud Console
2. Click on the **CONFIGURATION** tab
3. Find **Object Versioning**
4. Click **EDIT** and select **Enabled**
5. Click **SAVE**

**Option B: Using Cloud Shell or Terminal**
```bash
# Replace YOUR-BUCKET-NAME with your actual bucket name
gsutil versioning set on gs://YOUR-BUCKET-NAME

# Verify versioning is enabled
gsutil versioning get gs://YOUR-BUCKET-NAME
# Should output: gs://YOUR-BUCKET-NAME: Enabled
```

### Step 3: Upload Excel or ZIP Files to Your Bucket

Upload some Excel (.xlsx, .xls) or ZIP files to test:

```bash
# Upload a file
gsutil cp your-file.xlsx gs://YOUR-BUCKET-NAME/

# Upload multiple files
gsutil cp *.xlsx gs://YOUR-BUCKET-NAME/

# List files in your bucket
gsutil ls gs://YOUR-BUCKET-NAME/
```

### Step 4: Authenticate with Google Cloud

**If using Cloud Shell (Recommended):**
Cloud Shell is already authenticated! Just run:
```bash
gcloud auth application-default login
```

**If using a local machine or VM:**
```bash
# First, login to gcloud
gcloud auth login

# Then set up application default credentials
gcloud auth application-default login

# Verify you're authenticated
gcloud auth list
```

### Step 5: Set Your GCP Project

```bash
# List available projects
gcloud projects list

# Set your project
gcloud config set project YOUR-PROJECT-ID
```

### Step 6: Verify IAM Permissions

Make sure you have the necessary permissions on the bucket:

```bash
# Check your permissions
gsutil iam get gs://YOUR-BUCKET-NAME/

# If needed, grant yourself Storage Object Viewer permission
gsutil iam ch user:YOUR-EMAIL@example.com:objectViewer gs://YOUR-BUCKET-NAME/
```

Required permissions:
- `storage.objects.get` - To download files
- `storage.objects.list` - To list files
- `storage.buckets.get` - To access bucket metadata

### Step 7: Run the Application

**In Cloud Shell:**
```bash
# Clone the repository
git clone https://github.com/DEVOPS-ACTIVITIES/excel_versioning.git
cd excel_versioning

# Install dependencies
pip install -r requirements.txt

# Run the application
python app.py
```

The application will be available at `http://localhost:5001`

**In Cloud Shell, click the Web Preview button (port 5001) to access the application**

### Step 8: Connect to Your Bucket in the Application

1. Open the application in your browser
2. You'll see the **GCS Bucket Connection** section
3. Enter your bucket name (just the name, not `gs://bucket-name`)
4. Click **Connect to GCS Bucket**
5. If successful, you'll see "✓ Connected to [your-bucket-name]"
6. Your files will appear in the **Select File** dropdown

### Step 9: Compare File Versions

1. Select a file from the dropdown
2. Choose two different versions (First Version and Second Version)
3. Click **Compare Commits** to see the differences
4. Or click **Preview** to view a single version

## Troubleshooting

### Error: "Authentication error"
**Solution:**
```bash
gcloud auth application-default login
```

### Error: "Bucket not found"
**Possible causes:**
- Bucket name is incorrect (check for typos)
- Bucket doesn't exist in your project
- You don't have permission to access the bucket

**Solutions:**
```bash
# List all buckets in your project
gsutil ls

# Check if the bucket exists
gsutil ls gs://YOUR-BUCKET-NAME/

# Verify your current project
gcloud config get-value project
```

### Error: "Versioning is not enabled"
**Solution:**
```bash
# Enable versioning
gsutil versioning set on gs://YOUR-BUCKET-NAME/

# Verify it's enabled
gsutil versioning get gs://YOUR-BUCKET-NAME/
```

### Error: "Access denied"
**Solution:**
```bash
# Grant yourself the necessary role
gcloud projects add-iam-policy-binding YOUR-PROJECT-ID \
    --member="user:YOUR-EMAIL@example.com" \
    --role="roles/storage.objectViewer"
```

### No files showing up
**Possible causes:**
- Bucket is empty
- Files don't have supported extensions (.xlsx, .xls, .zip)
- Authentication issue

**Solutions:**
```bash
# Upload some test files
gsutil cp test.xlsx gs://YOUR-BUCKET-NAME/

# List files to verify they're there
gsutil ls gs://YOUR-BUCKET-NAME/
```

### Connection successful but no versions showing
**Cause:** The file needs to be updated to create multiple versions

**Solution:**
```bash
# Upload the same file multiple times to create versions
gsutil cp test-v1.xlsx gs://YOUR-BUCKET-NAME/test.xlsx
# Make changes to the file, then upload again
gsutil cp test-v2.xlsx gs://YOUR-BUCKET-NAME/test.xlsx

# List all versions
gsutil ls -a gs://YOUR-BUCKET-NAME/test.xlsx
```

## Quick Reference Commands

```bash
# Authentication
gcloud auth application-default login

# Set project
gcloud config set project YOUR-PROJECT-ID

# Enable versioning
gsutil versioning set on gs://YOUR-BUCKET-NAME

# Upload file
gsutil cp file.xlsx gs://YOUR-BUCKET-NAME/

# List files
gsutil ls gs://YOUR-BUCKET-NAME/

# List all versions of a file
gsutil ls -a gs://YOUR-BUCKET-NAME/file.xlsx

# Check versioning status
gsutil versioning get gs://YOUR-BUCKET-NAME
```

## Example Workflow

Here's a complete example from start to finish:

```bash
# 1. Set up your GCP project
gcloud config set project my-project-id

# 2. Authenticate
gcloud auth application-default login

# 3. Create and configure bucket
gsutil mb gs://my-excel-bucket
gsutil versioning set on gs://my-excel-bucket

# 4. Upload initial version of a file
gsutil cp sales-report.xlsx gs://my-excel-bucket/

# 5. Update the file and upload again (creates version 2)
# (make changes to sales-report.xlsx first)
gsutil cp sales-report.xlsx gs://my-excel-bucket/

# 6. Upload another version (creates version 3)
# (make more changes)
gsutil cp sales-report.xlsx gs://my-excel-bucket/

# 7. Verify you have multiple versions
gsutil ls -a gs://my-excel-bucket/sales-report.xlsx

# 8. Run the application
python app.py

# 9. In the application:
#    - Enter bucket name: my-excel-bucket
#    - Click "Connect to GCS Bucket"
#    - Select "sales-report.xlsx" from dropdown
#    - Choose two versions to compare
#    - Click "Compare Commits"
```

## Additional Resources

- [GCS Versioning Documentation](https://cloud.google.com/storage/docs/object-versioning)
- [gcloud CLI Documentation](https://cloud.google.com/sdk/gcloud/reference)
- [gsutil Tool Documentation](https://cloud.google.com/storage/docs/gsutil)
- [Cloud Shell Documentation](https://cloud.google.com/shell/docs)

## Need Help?

If you're still experiencing issues:
1. Check the browser console for JavaScript errors (F12 > Console tab)
2. Check the application logs in the terminal where you ran `python app.py`
3. Verify all prerequisites are met
4. Try the example workflow above step by step
