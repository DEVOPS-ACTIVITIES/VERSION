# Running with Docker in Google Cloud Shell

This guide explains how to run the Excel & ZIP File Data Versioning application with Docker in Google Cloud Shell for GCS bucket access.

## Important: Docker + GCS Credentials

When running in Docker, the container needs access to your Google Cloud credentials. The `docker-compose.yml` file has been configured to automatically mount your credentials, but you need to authenticate first.

## Setup Steps

### 1. Authenticate with Google Cloud

**Before running Docker**, authenticate in Cloud Shell:

```bash
# This creates credentials that will be mounted into the Docker container
gcloud auth application-default login
```

This command creates credentials at `~/.config/gcloud/application_default_credentials.json` which will be mounted into the container.

### 2. Enable Versioning on Your Bucket

```bash
# Enable versioning
gsutil versioning set on gs://your-bucket-name

# Verify it's enabled
gsutil versioning get gs://your-bucket-name
```

### 3. Upload Test Files

```bash
# Upload an Excel or ZIP file
gsutil cp test-file.xlsx gs://your-bucket-name/

# Upload it again to create a second version
gsutil cp test-file-v2.xlsx gs://your-bucket-name/test-file.xlsx

# Verify you have multiple versions
gsutil ls -a gs://your-bucket-name/test-file.xlsx
```

### 4. Run with Docker Compose

```bash
# Build and start the container
docker-compose up --build

# Or run in detached mode
docker-compose up --build -d
```

The application will be available at `http://localhost:5001`

In Cloud Shell, click the **Web Preview** button and select **Preview on port 5001**

### 5. Connect to Your Bucket

1. Open the application in your browser
2. Enter your bucket name (just the name, not `gs://bucket-name`)
3. Click "Connect to GCS Bucket"
4. Your files should appear in the dropdown

## Viewing Logs

To see what's happening and debug connection issues:

```bash
# View logs in real-time
docker-compose logs -f

# View logs for connection attempts
docker-compose logs | grep -i "bucket\|gcs\|auth"

# View just the last 50 lines
docker-compose logs --tail=50
```

## Troubleshooting

### Error: "Authentication error"

**Problem**: Docker container can't access your Google Cloud credentials

**Solution**:
1. Stop the container: `docker-compose down`
2. Run authentication: `gcloud auth application-default login`
3. Rebuild and restart: `docker-compose up --build`

**Verify credentials exist**:
```bash
# Check if credentials file exists
ls -la ~/.config/gcloud/application_default_credentials.json

# If it exists, you should see the file with size > 0
```

### Error: "No such file or directory: /root/.config/gcloud/application_default_credentials.json"

**Problem**: Credentials weren't created or aren't being mounted

**Solutions**:

1. **Make sure you ran the auth command**:
```bash
gcloud auth application-default login
```

2. **Verify the credentials file was created**:
```bash
cat ~/.config/gcloud/application_default_credentials.json
```

3. **If file doesn't exist**, try:
```bash
# Set your project first
gcloud config set project YOUR-PROJECT-ID

# Then authenticate again
gcloud auth application-default login
```

4. **Rebuild the container**:
```bash
docker-compose down
docker-compose up --build
```

### Container starts but can't connect to bucket

**Check the logs**:
```bash
docker-compose logs -f
```

Look for error messages about:
- Authentication
- Bucket access
- Versioning

**Common issues**:

1. **Wrong bucket name**: Verify with `gsutil ls`
2. **Wrong project**: Check with `gcloud config get-value project`
3. **Versioning not enabled**: Run `gsutil versioning set on gs://your-bucket-name`
4. **No permissions**: Grant yourself access with:
```bash
gsutil iam ch user:YOUR-EMAIL@example.com:objectViewer gs://your-bucket-name
```

### Can't see any logs

**Problem**: Container might not be running or logs aren't being output

**Check container status**:
```bash
# List running containers
docker ps

# If not running, check why
docker-compose ps

# See all logs including startup errors
docker-compose logs
```

### Connection works but no files appear

**Verify files exist in bucket**:
```bash
# List all files
gsutil ls gs://your-bucket-name/

# List with specific extension
gsutil ls gs://your-bucket-name/*.xlsx
```

**Make sure files have supported extensions**:
- `.xlsx` (Excel)
- `.xls` (Excel)
- `.zip` (ZIP archives)

### Web Preview not working in Cloud Shell

**Alternative access methods**:

1. **Use Cloud Shell's Web Preview**:
   - Click "Web Preview" button (top right)
   - Select "Preview on port 5001"

2. **Use the full URL**:
   - Cloud Shell provides a URL like `https://5001-dot-xxxx.cloudshell.dev`
   - Look for it in the Web Preview menu

3. **Port forwarding** (if using local machine):
   ```bash
   # In Cloud Shell
   gcloud cloud-shell ssh --ssh-flag="-L 5001:localhost:5001"
   ```
   Then access `http://localhost:5001` in your local browser

## Alternative: Run Without Docker

If Docker is causing issues, you can run directly in Cloud Shell:

```bash
# Authenticate (same as before)
gcloud auth application-default login

# Install dependencies
pip install -r requirements.txt

# Run the application
python app.py
```

Then use Web Preview on port 5001.

## Docker Commands Reference

```bash
# Start the application
docker-compose up

# Start in background
docker-compose up -d

# Stop the application
docker-compose down

# Rebuild after code changes
docker-compose up --build

# View logs
docker-compose logs -f

# Restart the application
docker-compose restart

# Remove containers and volumes
docker-compose down -v
```

## Verifying the Setup

Run these commands to verify everything is configured correctly:

```bash
# 1. Check authentication
gcloud auth list

# 2. Check credentials file
ls -la ~/.config/gcloud/application_default_credentials.json

# 3. Check bucket exists
gsutil ls gs://your-bucket-name/

# 4. Check versioning is enabled
gsutil versioning get gs://your-bucket-name/

# 5. Check you have files
gsutil ls gs://your-bucket-name/*.xlsx gs://your-bucket-name/*.zip 2>/dev/null

# 6. Check file versions exist
gsutil ls -a gs://your-bucket-name/
```

If all these commands succeed, Docker should work correctly!

## Success Checklist

- [ ] Authenticated with `gcloud auth application-default login`
- [ ] Credentials file exists at `~/.config/gcloud/application_default_credentials.json`
- [ ] Bucket exists and you can list it with `gsutil ls`
- [ ] Versioning is enabled on the bucket
- [ ] Excel or ZIP files are uploaded to the bucket
- [ ] Container is running (`docker ps` shows it)
- [ ] Can access application via Web Preview
- [ ] Logs show successful connection (`docker-compose logs`)

## Need More Help?

1. Check the logs: `docker-compose logs -f`
2. See the [Complete GCS Setup Guide](GCS_SETUP_GUIDE.md)
3. Try running without Docker as described above
4. Check that all success checklist items are completed
