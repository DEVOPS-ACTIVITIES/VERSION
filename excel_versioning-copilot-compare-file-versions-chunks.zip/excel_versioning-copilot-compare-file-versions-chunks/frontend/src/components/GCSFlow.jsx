import { useState, useEffect } from 'react'
import axios from 'axios'
import { Button } from 'primereact/button'
import { InputText } from 'primereact/inputtext'
import { Card } from 'primereact/card'
import { ProgressSpinner } from 'primereact/progressspinner'
import { Message } from 'primereact/message'
import { Dropdown } from 'primereact/dropdown'
import { Tag } from 'primereact/tag'
import { Divider } from 'primereact/divider'
import CompareView from './CompareView'

const STEPS = ['Connect', 'Select File', 'Choose Versions', 'Compare']

function StepProgress({ current }) {
  return (
    <div className="progress-steps">
      {STEPS.map((label, idx) => {
        const state = idx < current ? 'completed' : idx === current ? 'active' : 'pending'
        return (
          <div key={idx} className="flex align-items-center" style={{ flex: 1 }}>
            <div className="progress-step" style={{ flex: 0 }}>
              <div className={`progress-step-circle ${state}`}>
                {state === 'completed' ? <i className="pi pi-check" style={{ fontSize: '0.8rem' }}></i> : idx + 1}
              </div>
              <span className={`progress-step-label ${state === 'active' ? 'active' : ''}`}>{label}</span>
            </div>
            {idx < STEPS.length - 1 && (
              <div className={`progress-connector ${state === 'completed' ? 'completed' : ''}`} style={{ flex: 1 }}></div>
            )}
          </div>
        )
      })}
    </div>
  )
}

export default function GCSFlow({ onBack }) {
  const [step, setStep] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [bucketName, setBucketName] = useState('')
  const [prefix, setPrefix] = useState('')
  const [files, setFiles] = useState([])
  const [selectedFile, setSelectedFile] = useState(null)
  const [versions, setVersions] = useState([])
  const [newerVersion, setNewerVersion] = useState(null)
  const [olderVersion, setOlderVersion] = useState(null)
  const [compareResult, setCompareResult] = useState(null)
  const [comparing, setComparing] = useState(false)

  const handleConnect = async () => {
    if (!bucketName.trim()) { setError('Bucket name is required'); return }
    setLoading(true); setError('')
    try {
      await axios.post('/api/config/gcs', { bucket_name: bucketName, prefix })
      const res = await axios.get('/api/files')
      setFiles(res.data)
      setStep(1)
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to connect to GCS bucket')
    } finally {
      setLoading(false)
    }
  }

  const handleSelectFile = async (file) => {
    setSelectedFile(file)
    setLoading(true); setError('')
    try {
      const res = await axios.get('/api/gcs/versions', { params: { file } })
      const vs = res.data
      setVersions(vs)
      if (vs.length > 0) {
        setNewerVersion(vs[0])
        setOlderVersion(vs.length > 1 ? vs[1] : vs[0])
      }
      setStep(2)
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to load versions')
    } finally {
      setLoading(false)
    }
  }

  const handleCompare = async () => {
    if (!newerVersion || !olderVersion) { setError('Please select both versions'); return }
    setComparing(true); setError(''); setCompareResult(null)
    try {
      const res = await axios.post('/api/compare', {
        file: selectedFile,
        commit1: olderVersion.generation,
        commit2: newerVersion.generation,
      })
      setCompareResult(res.data)
      setStep(3)
    } catch (e) {
      setError(e.response?.data?.error || 'Comparison failed')
    } finally {
      setComparing(false)
    }
  }

  const getFileIcon = (filename) => {
    if (filename.endsWith('.xlsx') || filename.endsWith('.xls')) return 'pi pi-file-excel'
    if (filename.endsWith('.zip')) return 'pi pi-box'
    return 'pi pi-file'
  }

  const getFileColor = (filename) => {
    if (filename.endsWith('.xlsx') || filename.endsWith('.xls')) return '#16a34a'
    if (filename.endsWith('.zip')) return '#ea580c'
    return '#6366f1'
  }

  const formatDate = (ts) => {
    if (!ts) return ''
    return new Date(ts).toLocaleString()
  }

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
      <div className="glass-card glass-card--fullscreen animate-fade-in">
        {/* Header */}
        <div className="hero-gradient">
          <div className="flex align-items-center justify-content-between">
            <Button
              icon="pi pi-arrow-left"
              label="Back"
              className="p-button-text p-button-sm"
              style={{ color: 'white', border: '1px solid rgba(255,255,255,0.3)' }}
              onClick={onBack}
            />
            <div className="text-center flex-1">
              <div style={{ fontSize: '2rem', marginBottom: '4px' }}>
                <i className="pi pi-cloud" style={{ marginRight: '12px' }}></i>
                Google Cloud Storage
              </div>
              <div style={{ opacity: 0.8, fontSize: '0.9rem' }}>Compare Excel & ZIP file versions in your GCS bucket</div>
            </div>
            <div style={{ width: '80px' }}></div>
          </div>
        </div>

        <div className="p-5" style={{ maxWidth: '1400px', width: '100%', margin: '0 auto', flex: 1 }}>
          <StepProgress current={step} />

          {error && (
            <Message severity="error" text={error} className="w-full mb-4" />
          )}

          {/* Step 0: Connect */}
          {step === 0 && (
            <div className="animate-fade-in">
              <div className="flex flex-column gap-4" style={{ maxWidth: '600px', margin: '0 auto' }}>
                <div className="step-indicator mb-2">
                  <i className="pi pi-link"></i>
                  Step 1: Connect to your GCS Bucket
                </div>
                <div className="flex flex-column gap-2">
                  <label className="font-semibold" style={{ color: '#374151' }}>
                    <i className="pi pi-database mr-2" style={{ color: '#4285f4' }}></i>
                    Bucket Name <span style={{ color: '#ef4444' }}>*</span>
                  </label>
                  <InputText
                    value={bucketName}
                    onChange={e => setBucketName(e.target.value)}
                    placeholder="my-gcs-bucket"
                    onKeyDown={e => e.key === 'Enter' && handleConnect()}
                    style={{ borderRadius: '10px' }}
                  />
                </div>
                <div className="flex flex-column gap-2">
                  <label className="font-semibold" style={{ color: '#374151' }}>
                    <i className="pi pi-folder mr-2" style={{ color: '#4285f4' }}></i>
                    Prefix <span style={{ color: '#94a3b8', fontSize: '0.85rem' }}>(optional)</span>
                  </label>
                  <InputText
                    value={prefix}
                    onChange={e => setPrefix(e.target.value)}
                    placeholder="folder/subfolder/"
                    onKeyDown={e => e.key === 'Enter' && handleConnect()}
                    style={{ borderRadius: '10px' }}
                  />
                  <small style={{ color: '#94a3b8' }}>Filter files within a specific path in the bucket</small>
                </div>
                <Button
                  label={loading ? 'Connecting...' : 'Connect to Bucket'}
                  icon={loading ? 'pi pi-spin pi-spinner' : 'pi pi-cloud'}
                  disabled={loading}
                  onClick={handleConnect}
                  style={{
                    background: 'linear-gradient(135deg, #4285f4 0%, #34a853 100%)',
                    border: 'none',
                    borderRadius: '10px',
                    padding: '12px',
                    fontWeight: '600',
                    fontSize: '1rem'
                  }}
                />
              </div>
            </div>
          )}

          {/* Step 1: File Selection */}
          {step >= 1 && (
            <div className="animate-fade-in">
              <div className="step-indicator mb-4">
                <i className="pi pi-folder-open"></i>
                Step 2: Select a file to compare
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '12px' }}>
                {files.map((file, idx) => (
                  <div
                    key={idx}
                    className={`file-card p-3 border-round ${selectedFile === file ? 'selected' : ''}`}
                    style={{
                      background: selectedFile === file ? '#eef2ff' : '#f8fafc',
                      border: '2px solid',
                      borderColor: selectedFile === file ? '#6366f1' : '#e2e8f0',
                      cursor: 'pointer'
                    }}
                    onClick={() => handleSelectFile(file)}
                  >
                    <div className="flex align-items-center gap-3">
                      <div style={{
                        width: '40px', height: '40px', borderRadius: '10px',
                        background: selectedFile === file ? '#6366f1' : '#f1f5f9',
                        display: 'flex', alignItems: 'center', justifyContent: 'center'
                      }}>
                        <i className={getFileIcon(file)} style={{
                          color: selectedFile === file ? 'white' : getFileColor(file),
                          fontSize: '1.2rem'
                        }}></i>
                      </div>
                      <div style={{ overflow: 'hidden' }}>
                        <div style={{
                          fontWeight: '600',
                          fontSize: '0.85rem',
                          color: selectedFile === file ? '#4338ca' : '#1e293b',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap'
                        }}>
                          {file.split('/').pop()}
                        </div>
                        {file.includes('/') && (
                          <div style={{ fontSize: '0.75rem', color: '#94a3b8', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                            {file.split('/').slice(0, -1).join('/')}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              {loading && step === 1 && (
                <div className="flex justify-content-center mt-4">
                  <ProgressSpinner style={{ width: '40px', height: '40px' }} />
                </div>
              )}
            </div>
          )}

          {/* Step 2: Version Selection */}
          {step >= 2 && (
            <div className="animate-fade-in mt-5">
              <Divider />
              <div className="step-indicator mb-4">
                <i className="pi pi-history"></i>
                Step 3: Choose versions to compare
              </div>
              <div className="flex gap-4 flex-wrap">
                <div className="flex flex-column gap-2" style={{ flex: 1, minWidth: '200px' }}>
                  <label className="font-semibold" style={{ color: '#374151' }}>
                    <span className="version-badge version-newer mr-2">Newer Version</span>
                  </label>
                  <Dropdown
                    value={newerVersion}
                    options={versions}
                    onChange={e => setNewerVersion(e.value)}
                    optionLabel="label"
                    placeholder="Select newer version"
                    style={{ borderRadius: '10px' }}
                    itemTemplate={v => (
                      <div>
                        <div style={{ fontWeight: 600, fontSize: '0.85rem' }}>{v.label || v.generation}</div>
                        <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{formatDate(v.time_deleted || v.updated)}</div>
                      </div>
                    )}
                    valueTemplate={v => v ? (
                      <span>
                        <i className="pi pi-star-fill mr-1" style={{ color: '#3b82f6' }}></i>
                        {v.label || v.generation}
                      </span>
                    ) : 'Select newer version'}
                  />
                  <small style={{ color: '#94a3b8' }}>Default: latest version</small>
                </div>
                <div className="flex align-items-center" style={{ paddingTop: '30px' }}>
                  <i className="pi pi-arrows-h" style={{ color: '#94a3b8', fontSize: '1.5rem' }}></i>
                </div>
                <div className="flex flex-column gap-2" style={{ flex: 1, minWidth: '200px' }}>
                  <label className="font-semibold" style={{ color: '#374151' }}>
                    <span className="version-badge version-older mr-2">Older Version</span>
                  </label>
                  <Dropdown
                    value={olderVersion}
                    options={versions}
                    onChange={e => setOlderVersion(e.value)}
                    optionLabel="label"
                    placeholder="Select older version"
                    style={{ borderRadius: '10px' }}
                    itemTemplate={v => (
                      <div>
                        <div style={{ fontWeight: 600, fontSize: '0.85rem' }}>{v.label || v.generation}</div>
                        <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>{formatDate(v.time_deleted || v.updated)}</div>
                      </div>
                    )}
                    valueTemplate={v => v ? (
                      <span>
                        <i className="pi pi-history mr-1" style={{ color: '#7c3aed' }}></i>
                        {v.label || v.generation}
                      </span>
                    ) : 'Select older version'}
                  />
                </div>
              </div>
              <Button
                label={comparing ? 'Comparing...' : 'Compare Versions'}
                icon={comparing ? 'pi pi-spin pi-spinner' : 'pi pi-code-branch'}
                disabled={comparing || !newerVersion || !olderVersion}
                onClick={handleCompare}
                className="mt-4"
                style={{
                  background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
                  border: 'none',
                  borderRadius: '10px',
                  padding: '12px 32px',
                  fontWeight: '600',
                  fontSize: '1rem'
                }}
              />
            </div>
          )}

          {/* Step 3: Compare Results */}
          {step >= 3 && compareResult && (
            <div className="animate-fade-in mt-5">
              <Divider />
              <div className="step-indicator mb-4">
                <i className="pi pi-chart-line"></i>
                Step 4: Comparison Results
              </div>
              <CompareView
                result={compareResult}
                newerLabel={newerVersion?.label || newerVersion?.generation || ''}
                olderLabel={olderVersion?.label || olderVersion?.generation || ''}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
