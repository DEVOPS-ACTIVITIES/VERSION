import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { resolve } from 'path'

// Flask backend URL for development proxy
const FLASK_BACKEND = process.env.VITE_BACKEND_URL || 'http://localhost:5001'

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api': FLASK_BACKEND,
      '/preview': FLASK_BACKEND,
    },
  },
  build: {
    outDir: resolve(__dirname, '../static'),
    emptyOutDir: true,
    rollupOptions: {
      output: {
        assetFileNames: 'assets/[name]-[hash][extname]',
        chunkFileNames: 'assets/[name]-[hash].js',
        entryFileNames: 'assets/[name]-[hash].js',
      },
    },
  },
})
