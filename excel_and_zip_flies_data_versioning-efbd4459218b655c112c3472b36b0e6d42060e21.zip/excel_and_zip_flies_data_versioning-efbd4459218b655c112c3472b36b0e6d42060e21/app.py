"""
Excel and ZIP File Data Versioning Web Application
This application allows users to view differences in Excel and ZIP files
between different commits in a GitHub repository.
Supports both local repositories and remote GitHub repositories via URL and token.
"""

from flask import Flask, render_template, request, jsonify, session
import os
import subprocess
import pandas as pd
import zipfile
from io import BytesIO
import tempfile
import shutil
from urllib.parse import urlparse

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24).hex())

# Configuration
DEFAULT_REPO_PATH = os.getcwd()
TEMP_REPOS_DIR = tempfile.mkdtemp(prefix='git_repos_')

# Cleanup temp directory on exit
import atexit

@atexit.register
def cleanup_temp_repos():
    """Clean up temporary repositories directory on exit."""
    try:
        if os.path.exists(TEMP_REPOS_DIR):
            shutil.rmtree(TEMP_REPOS_DIR)
            print(f"Cleaned up temporary directory: {TEMP_REPOS_DIR}")
    except Exception as e:
        print(f"Error cleaning up temp directory: {e}")


def get_repo_path():
    """Get the current repository path from session or default."""
    return session.get('repo_path', DEFAULT_REPO_PATH)


def clone_or_update_repo(github_url, token=None):
    """Clone or update a repository from GitHub."""
    try:
        # Parse the URL to get repo name
        parsed_url = urlparse(github_url)
        repo_name = parsed_url.path.strip('/').replace('/', '_')
        
        # Ensure .git extension
        clean_url = github_url if github_url.endswith('.git') else github_url + '.git'
        
        repo_path = os.path.join(TEMP_REPOS_DIR, repo_name)
        
        # Set up environment with token if provided
        env = os.environ.copy()
        if token:
            # Use GIT_ASKPASS to provide credentials securely
            env['GIT_TERMINAL_PROMPT'] = '0'
            # Create authenticated URL for git operations
            auth_url = clean_url.replace('https://', f'https://{token}@')
        else:
            auth_url = clean_url
        
        # Check if repo already exists
        if os.path.exists(repo_path):
            # Update existing repo
            print(f"Updating repository at {repo_path}")
            result = subprocess.run(
                ['git', 'fetch', '--all'],
                cwd=repo_path,
                capture_output=True,
                text=True,
                timeout=60,
                env=env
            )
            if result.returncode != 0:
                # Don't expose token in error messages
                error_msg = result.stderr.replace(token if token else '', '***') if token else result.stderr
                return None, f"Failed to update repository: {error_msg}"
        else:
            # Clone new repo
            print(f"Cloning repository to {repo_path}")
            result = subprocess.run(
                ['git', 'clone', auth_url, repo_path],
                capture_output=True,
                text=True,
                timeout=120,
                env=env
            )
            if result.returncode != 0:
                # Don't expose token in error messages
                error_msg = result.stderr.replace(token if token else '', '***') if token else result.stderr
                return None, f"Failed to clone repository: {error_msg}"
        
        return repo_path, None
    except subprocess.TimeoutExpired:
        return None, "Operation timed out. Please check your network connection."
    except Exception as e:
        return None, f"Error: {str(e)}"


def get_branches():
    """Get list of all branches in the repository."""
    try:
        repo_path = get_repo_path()
        is_github = repo_path != DEFAULT_REPO_PATH
        
        # Get local and remote branches
        if is_github:
            # For GitHub repos, show remote branches
            result = subprocess.run(
                ['git', 'branch', '-r'],
                cwd=repo_path,
                capture_output=True,
                text=True,
                check=True
            )
        else:
            # For local repos, show local branches
            result = subprocess.run(
                ['git', 'branch'],
                cwd=repo_path,
                capture_output=True,
                text=True,
                check=True
            )
        
        branches = []
        for line in result.stdout.strip().split('\n'):
            if line:
                # Remove * and whitespace
                branch = line.strip().lstrip('* ').strip()
                # Skip HEAD pointer
                if '-> ' not in branch and branch:
                    branches.append(branch)
        
        return branches
    except subprocess.CalledProcessError as e:
        print(f"Error getting branches: {e}")
        return []


def get_commits_for_branch(branch):
    """Get list of commits for a specific branch."""
    try:
        repo_path = get_repo_path()
        
        result = subprocess.run(
            ['git', 'log', branch, '--pretty=format:%H|||%s|||%an|||%ad', '--date=format:%Y-%m-%d %H:%M:%S'],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True
        )
        commits = []
        for line in result.stdout.strip().split('\n'):
            if line:
                parts = line.split('|||')
                if len(parts) >= 4:
                    commits.append({
                        'hash': parts[0],
                        'message': parts[1],
                        'author': parts[2],
                        'date': parts[3]
                    })
        return commits
    except subprocess.CalledProcessError as e:
        print(f"Error getting commits for branch: {e}")
        return []


def get_all_commits():
    """Get list of all commits with their hash and message."""
    try:
        repo_path = get_repo_path()
        is_github = repo_path != DEFAULT_REPO_PATH
        
        # When connected to GitHub, use --all to see commits from all branches including remote tracking branches
        # This ensures fetched commits from remote are visible
        git_log_cmd = ['git', 'log', '--pretty=format:%H|||%s|||%an|||%ad', '--date=format:%Y-%m-%d %H:%M:%S']
        if is_github:
            git_log_cmd.insert(2, '--all')  # Insert --all after 'git log'
        
        result = subprocess.run(
            git_log_cmd,
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True
        )
        commits = []
        for line in result.stdout.strip().split('\n'):
            if line:
                parts = line.split('|||')
                if len(parts) >= 4:
                    commits.append({
                        'hash': parts[0],
                        'message': parts[1],
                        'author': parts[2],
                        'date': parts[3]
                    })
        return commits
    except subprocess.CalledProcessError as e:
        print(f"Error getting commits: {e}")
        return []


def get_files_at_commit(commit_hash):
    """Get list of Excel and ZIP files at a specific commit."""
    try:
        repo_path = get_repo_path()
        result = subprocess.run(
            ['git', 'ls-tree', '-r', '--name-only', commit_hash],
            cwd=repo_path,
            capture_output=True,
            text=True,
            check=True
        )
        files = result.stdout.strip().split('\n')
        # Filter for Excel and ZIP files
        filtered_files = [
            f for f in files 
            if f.lower().endswith(('.xlsx', '.xls', '.zip'))
        ]
        return filtered_files
    except subprocess.CalledProcessError as e:
        print(f"Error getting files: {e}")
        return []


def get_file_content(commit_hash, file_path):
    """Get file content at a specific commit."""
    try:
        repo_path = get_repo_path()
        result = subprocess.run(
            ['git', 'show', f'{commit_hash}:{file_path}'],
            cwd=repo_path,
            capture_output=True,
            check=True
        )
        return result.stdout
    except subprocess.CalledProcessError as e:
        print(f"Error getting file content: {e}")
        return None


def parse_excel_data(file_content):
    """Parse Excel file content and return data as dictionary."""
    try:
        with BytesIO(file_content) as bio:
            # Try reading with pandas first
            excel_data = {}
            xls = pd.ExcelFile(bio)
            for sheet_name in xls.sheet_names:
                df = pd.read_excel(bio, sheet_name=sheet_name)
                excel_data[sheet_name] = df.to_dict('records')
            return excel_data
    except Exception as e:
        print(f"Error parsing Excel: {e}")
        return None


def parse_zip_data(file_content):
    """Parse ZIP file content and return list of files."""
    try:
        with BytesIO(file_content) as bio:
            with zipfile.ZipFile(bio, 'r') as zip_ref:
                file_list = []
                for file_info in zip_ref.filelist:
                    file_data = {
                        'filename': file_info.filename,
                        'size': file_info.file_size,
                        'compressed_size': file_info.compress_size,
                        'is_dir': file_info.is_dir()
                    }
                    # Try to read small text files
                    if not file_info.is_dir() and file_info.file_size < 100000:
                        try:
                            content = zip_ref.read(file_info.filename)
                            # Try to decode as text
                            try:
                                file_data['content'] = content.decode('utf-8')
                            except UnicodeDecodeError:
                                file_data['content'] = f"<binary data: {len(content)} bytes>"
                        except (zipfile.BadZipFile, KeyError, PermissionError):
                            file_data['content'] = "<unable to read>"
                    file_list.append(file_data)
                return file_list
    except Exception as e:
        print(f"Error parsing ZIP: {e}")
        return None


def compare_excel_data(data1, data2, filename=''):
    """Compare two Excel data structures and return differences - Table view with cell-level data."""
    differences = []
    
    # Maximum number of rows to display for added/removed sheets (to prevent performance issues)
    MAX_ROWS_DISPLAY = 100
    
    def extract_sheet_data(rows, max_rows=MAX_ROWS_DISPLAY):
        """
        Helper function to extract columns and rows from sheet data.
        Returns (columns, all_rows, is_truncated, total_rows)
        """
        columns = []
        all_rows = []
        is_truncated = False
        total_rows = 0
        
        try:
            if not rows:
                return columns, all_rows, is_truncated, total_rows
            
            total_rows = len(rows)
            
            # Get columns from the first row
            if total_rows > 0 and rows[0]:
                columns = list(rows[0].keys())
            
            # Limit rows to prevent performance issues
            rows_to_process = rows[:max_rows]
            if total_rows > max_rows:
                is_truncated = True
            
            # Convert rows to cells for display
            for row in rows_to_process:
                cells = []
                for col in columns:
                    try:
                        val = row.get(col)
                        if pd.isna(val):
                            cells.append('')
                        else:
                            cells.append(str(val))
                    except Exception:
                        cells.append('')  # Handle any errors gracefully
                all_rows.append(cells)
                
        except Exception as e:
            print(f"Error extracting sheet data: {e}")
            # Return empty data on error
            return [], [], False, 0
        
        return columns, all_rows, is_truncated, total_rows
    
    # Get all sheet names from both files
    sheets1 = set(data1.keys()) if data1 else set()
    sheets2 = set(data2.keys()) if data2 else set()
    
    # Sheets only in first commit (removed sheets)
    for sheet in sheets1 - sheets2:
        rows = data1[sheet]
        columns, all_rows, is_truncated, total_rows = extract_sheet_data(rows)
        
        message = f"Sheet '{sheet}' was removed from '{filename}'"
        if total_rows == 0:
            message += " (sheet was empty)"
        elif is_truncated:
            message += f" (showing first {len(all_rows)} of {total_rows} rows)"
        
        differences.append({
            'type': 'sheet_removed',
            'sheet': sheet,
            'filename': filename,
            'columns': columns,
            'rows': all_rows,
            'total_rows': total_rows,
            'is_truncated': is_truncated,
            'message': message
        })
    
    # Sheets only in second commit (added sheets)
    for sheet in sheets2 - sheets1:
        rows = data2[sheet]
        columns, all_rows, is_truncated, total_rows = extract_sheet_data(rows)
        
        message = f"Sheet '{sheet}' was added to '{filename}'"
        if total_rows == 0:
            message += " (sheet was empty)"
        elif is_truncated:
            message += f" (showing first {len(all_rows)} of {total_rows} rows)"
        
        differences.append({
            'type': 'sheet_added',
            'sheet': sheet,
            'filename': filename,
            'columns': columns,
            'rows': all_rows,
            'total_rows': total_rows,
            'is_truncated': is_truncated,
            'message': message
        })
    
    # Compare common sheets - Table view with row-level comparison
    for sheet in sheets1 & sheets2:
        rows1 = data1[sheet]
        rows2 = data2[sheet]
        
        # Get column names preserving order from the Excel file
        # Use the first non-empty row to determine column order
        all_cols = []
        cols_seen = set()
        
        # Get columns from first version in their original order
        if rows1 and len(rows1) > 0:
            for col in rows1[0].keys():
                if col not in cols_seen:
                    all_cols.append(col)
                    cols_seen.add(col)
        
        # Add any new columns from second version at the end
        if rows2 and len(rows2) > 0:
            for col in rows2[0].keys():
                if col not in cols_seen:
                    all_cols.append(col)
                    cols_seen.add(col)
        
        # Convert rows to CSV-like format for comparison (internal use only)
        def row_to_csv(row, cols):
            """Convert a row dict to CSV string with column values"""
            values = []
            for col in cols:
                val = row.get(col)
                if pd.isna(val):
                    values.append('')
                else:
                    # Quote values that contain commas
                    val_str = str(val)
                    if ',' in val_str:
                        values.append(f'"{val_str}"')
                    else:
                        values.append(val_str)
            return ','.join(values)
        
        # Get cell values as a list
        def row_to_cells(row, cols):
            """Convert a row dict to list of cell values"""
            cells = []
            for col in cols:
                val = row.get(col)
                if pd.isna(val):
                    cells.append('')
                else:
                    cells.append(str(val))
            return cells
        
        # Create CSV lines for each row (for comparison)
        csv_lines1 = []
        csv_lines2 = []
        
        for i, row in enumerate(rows1):
            csv_lines1.append(row_to_csv(row, all_cols))
        
        for i, row in enumerate(rows2):
            csv_lines2.append(row_to_csv(row, all_cols))
        
        # Use difflib to compare lines
        import difflib
        differ = difflib.SequenceMatcher(None, csv_lines1, csv_lines2)
        
        # Generate line-by-line diff with row numbers
        diff_lines = []
        
        for tag, i1, i2, j1, j2 in differ.get_opcodes():
            if tag == 'equal':
                # Lines are the same - optionally include context
                continue  # Skip unchanged lines for now
            elif tag == 'delete':
                # Lines only in first version (removed rows)
                for i in range(i1, i2):
                    diff_lines.append({
                        'type': 'removed',
                        'old_line_num': i + 1,
                        'new_line_num': None,
                        'content': csv_lines1[i],
                        'cells': row_to_cells(rows1[i], all_cols)
                    })
            elif tag == 'insert':
                # Lines only in second version (added rows)
                for j in range(j1, j2):
                    diff_lines.append({
                        'type': 'added',
                        'old_line_num': None,
                        'new_line_num': j + 1,
                        'content': csv_lines2[j],
                        'cells': row_to_cells(rows2[j], all_cols)
                    })
            elif tag == 'replace':
                # Lines changed - show old and new
                for i in range(i1, i2):
                    diff_lines.append({
                        'type': 'removed',
                        'old_line_num': i + 1,
                        'new_line_num': None,
                        'content': csv_lines1[i],
                        'cells': row_to_cells(rows1[i], all_cols)
                    })
                for j in range(j1, j2):
                    diff_lines.append({
                        'type': 'added',
                        'old_line_num': None,
                        'new_line_num': j + 1,
                        'content': csv_lines2[j],
                        'cells': row_to_cells(rows2[j], all_cols)
                    })
        
        # Add the table-style diff for this sheet if there are changes
        if diff_lines:
            differences.append({
                'type': 'sheet_table_diff',
                'sheet': sheet,
                'filename': filename,
                'columns': all_cols,
                'diff_lines': diff_lines,
                'message': f"Sheet '{sheet}': {len(diff_lines)} line(s) changed"
            })
    
    return differences


def compare_zip_data(data1, data2):
    """Compare two ZIP file structures and return differences."""
    differences = []
    
    # Create dictionaries for easier comparison
    files1 = {f['filename']: f for f in data1} if data1 else {}
    files2 = {f['filename']: f for f in data2} if data2 else {}
    
    # Files only in first commit (removed)
    for filename in set(files1.keys()) - set(files2.keys()):
        file1 = files1[filename]
        # Show content of removed files
        if 'content' in file1 and file1['content']:
            lines = file1['content'].splitlines(keepends=False)
            line_changes = []
            for i, line in enumerate(lines, start=1):
                line_changes.append({
                    'type': 'removed',
                    'old_line_num': i,
                    'new_line_num': None,
                    'content': line
                })
            differences.append({
                'type': 'content_change_lines',
                'filename': filename,
                'line_changes': line_changes,
                'message': f"File '{filename}' was removed from ZIP"
            })
        else:
            differences.append({
                'type': 'file_removed',
                'filename': filename,
                'message': f"File '{filename}' was removed from ZIP"
            })
    
    # Files only in second commit (added)
    for filename in set(files2.keys()) - set(files1.keys()):
        file2 = files2[filename]
        # Show content of added files
        if 'content' in file2 and file2['content']:
            lines = file2['content'].splitlines(keepends=False)
            line_changes = []
            for i, line in enumerate(lines, start=1):
                line_changes.append({
                    'type': 'added',
                    'old_line_num': None,
                    'new_line_num': i,
                    'content': line
                })
            differences.append({
                'type': 'content_change_lines',
                'filename': filename,
                'line_changes': line_changes,
                'message': f"File '{filename}' was added to ZIP"
            })
        else:
            differences.append({
                'type': 'file_added',
                'filename': filename,
                'message': f"File '{filename}' was added to ZIP"
            })
    
    # Compare common files
    for filename in set(files1.keys()) & set(files2.keys()):
        file1 = files1[filename]
        file2 = files2[filename]
        
        # Compare content if available
        if 'content' in file1 and 'content' in file2:
            if file1['content'] != file2['content']:
                # Compute line-by-line diff with context
                import difflib
                lines1 = file1['content'].splitlines(keepends=False)
                lines2 = file2['content'].splitlines(keepends=False)
                
                # Use unified diff with context lines (default is 3 lines of context)
                diff_lines = []
                differ = difflib.unified_diff(
                    lines1, lines2,
                    fromfile=f'{filename} (old)',
                    tofile=f'{filename} (new)',
                    lineterm='',
                    n=3  # number of context lines
                )
                
                # Parse the diff output more accurately
                line_changes = []
                old_line_num = 0
                new_line_num = 0
                in_hunk = False
                
                for line in differ:
                    if line.startswith('---') or line.startswith('+++'):
                        continue
                    elif line.startswith('@@'):
                        # Parse line numbers from hunk header
                        import re
                        match = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', line)
                        if match:
                            old_line_num = int(match.group(1))
                            new_line_num = int(match.group(3))
                            in_hunk = True
                    elif in_hunk:
                        if line.startswith('-'):
                            line_changes.append({
                                'type': 'removed',
                                'old_line_num': old_line_num,
                                'new_line_num': None,
                                'content': line[1:]
                            })
                            old_line_num += 1
                        elif line.startswith('+'):
                            line_changes.append({
                                'type': 'added',
                                'old_line_num': None,
                                'new_line_num': new_line_num,
                                'content': line[1:]
                            })
                            new_line_num += 1
                        elif line.startswith(' '):
                            # Context line (unchanged)
                            line_changes.append({
                                'type': 'context',
                                'old_line_num': old_line_num,
                                'new_line_num': new_line_num,
                                'content': line[1:]
                            })
                            old_line_num += 1
                            new_line_num += 1
                
                differences.append({
                    'type': 'content_change_lines',
                    'filename': filename,
                    'line_changes': line_changes,
                    'message': f"File '{filename}': Content changed"
                })
    
    return differences


@app.route('/')
def index():
    """Main page."""
    return render_template('index.html')


@app.route('/api/config/github', methods=['POST'])
def api_config_github():
    """Configure GitHub repository connection."""
    data = request.json
    github_url = data.get('github_url', '').strip()
    token = data.get('token', '').strip()
    
    if not github_url:
        return jsonify({'error': 'GitHub URL is required'}), 400
    
    # Validate URL format
    if not github_url.startswith('https://'):
        return jsonify({'error': 'Please provide a valid HTTPS URL'}), 400
    
    # Clone or update the repository
    repo_path, error = clone_or_update_repo(github_url, token if token else None)
    
    if error:
        return jsonify({'error': error}), 500
    
    # Store repo path in session
    session['repo_path'] = repo_path
    session['github_url'] = github_url
    
    return jsonify({
        'success': True,
        'message': 'Repository connected successfully',
        'repo_path': repo_path
    })


@app.route('/api/config/status')
def api_config_status():
    """Get current configuration status."""
    repo_path = get_repo_path()
    is_github = repo_path != DEFAULT_REPO_PATH
    
    return jsonify({
        'is_configured': is_github,
        'repo_path': repo_path,
        'github_url': session.get('github_url', ''),
        'using_local': not is_github
    })


@app.route('/api/config/reset', methods=['POST'])
def api_config_reset():
    """Reset to local repository."""
    session.pop('repo_path', None)
    session.pop('github_url', None)
    
    return jsonify({
        'success': True,
        'message': 'Reset to local repository'
    })


@app.route('/api/config/refresh', methods=['POST'])
def api_config_refresh():
    """Refresh repository to fetch latest commits."""
    repo_path = get_repo_path()
    is_github = repo_path != DEFAULT_REPO_PATH
    
    if not is_github:
        # For local repository, no fetch needed - just reload
        return jsonify({
            'success': True,
            'message': 'Local repository refreshed'
        })
    
    # For GitHub repository, fetch latest commits
    try:
        github_url = session.get('github_url', '')
        if not github_url:
            return jsonify({'error': 'No GitHub repository configured'}), 400
        
        # Fetch updates from remote
        result = subprocess.run(
            ['git', 'fetch', '--all'],
            cwd=repo_path,
            capture_output=True,
            text=True,
            timeout=60
        )
        
        if result.returncode != 0:
            return jsonify({'error': f'Failed to fetch updates: {result.stderr}'}), 500
        
        # Note: We only fetch, not pull, to avoid merge conflicts
        # The fetched commits will be visible through git log
        return jsonify({
            'success': True,
            'message': 'Repository refreshed successfully. New commits fetched from remote.'
        })
    except subprocess.TimeoutExpired:
        return jsonify({'error': 'Refresh timed out. Please check your network connection.'}), 500
    except Exception as e:
        return jsonify({'error': f'Failed to refresh: {str(e)}'}), 500


@app.route('/api/branches')
def api_branches():
    """API endpoint to get all branches."""
    branches = get_branches()
    return jsonify(branches)


@app.route('/api/commits')
def api_commits():
    """API endpoint to get all commits."""
    branch = request.args.get('branch')
    if branch:
        commits = get_commits_for_branch(branch)
    else:
        commits = get_all_commits()
    return jsonify(commits)


@app.route('/api/files')
def api_files():
    """API endpoint to get files at a commit."""
    commit_hash = request.args.get('commit')
    if not commit_hash:
        # Get files from all commits
        commits = get_all_commits()
        all_files = set()
        for commit in commits[:10]:  # Check last 10 commits
            files = get_files_at_commit(commit['hash'])
            all_files.update(files)
        return jsonify(list(all_files))
    
    files = get_files_at_commit(commit_hash)
    return jsonify(files)


@app.route('/api/compare', methods=['POST'])
def api_compare():
    """API endpoint to compare a file between two commits."""
    data = request.json
    commit1 = data.get('commit1')
    commit2 = data.get('commit2')
    file_path = data.get('file')
    
    if not all([commit1, commit2, file_path]):
        return jsonify({'error': 'Missing required parameters'}), 400
    
    # Get file content from both commits
    content1 = get_file_content(commit1, file_path)
    content2 = get_file_content(commit2, file_path)
    
    if content1 is None:
        return jsonify({'error': f'File not found in commit {commit1}'}), 404
    if content2 is None:
        return jsonify({'error': f'File not found in commit {commit2}'}), 404
    
    # Determine file type and parse accordingly
    file_lower = file_path.lower()
    differences = []
    
    if file_lower.endswith(('.xlsx', '.xls')):
        # Parse Excel files
        data1 = parse_excel_data(content1)
        data2 = parse_excel_data(content2)
        
        if data1 is None or data2 is None:
            return jsonify({'error': 'Failed to parse Excel file'}), 500
        
        differences = compare_excel_data(data1, data2, file_path)
        file_type = 'excel'
        
    elif file_lower.endswith('.zip'):
        # Parse ZIP files
        data1 = parse_zip_data(content1)
        data2 = parse_zip_data(content2)
        
        if data1 is None or data2 is None:
            return jsonify({'error': 'Failed to parse ZIP file'}), 500
        
        differences = compare_zip_data(data1, data2)
        file_type = 'zip'
    else:
        return jsonify({'error': 'Unsupported file type'}), 400
    
    return jsonify({
        'file_type': file_type,
        'differences': differences,
        'total_changes': len(differences)
    })


if __name__ == '__main__':
    # Debug mode should only be enabled in development
    # Set debug=False or use environment variable for production
    debug_mode = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    app.run(debug=debug_mode, host='0.0.0.0', port=5001)
