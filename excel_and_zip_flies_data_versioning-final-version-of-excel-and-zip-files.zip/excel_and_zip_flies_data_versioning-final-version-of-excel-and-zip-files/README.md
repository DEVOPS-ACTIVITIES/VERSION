# Excel and ZIP File Data Versioning

A Python web application that allows you to view and compare Excel and ZIP files between different commits in a Git repository. This tool helps you visualize data changes and file modifications across your version history.

## Features

- 📊 **Excel File Comparison**: Compare data in Excel files (.xlsx, .xls) across commits
- 📦 **ZIP File Comparison**: Compare contents and files within ZIP archives
- 🔍 **Detailed Difference View**: See exactly what changed between commits
- 🎨 **User-Friendly Interface**: Simple dropdown-based UI for selecting files and commits
- 📈 **Change Detection**: Identifies added, removed, and modified data
- 🔗 **GitHub Integration**: Connect to remote GitHub repositories using URL and token
- 🌐 **Local & Remote Support**: Works with both local repositories and remote GitHub repos

## Prerequisites

### Option 1: Running with Docker (Recommended)
- Docker installed on your system
- Docker Compose (optional, for easier management)

### Option 2: Running with Python
- Python 3.8 or higher
- Git repository with Excel or ZIP files
- pip (Python package manager)

## Installation and Usage

### Option 1: Using Docker (Recommended)

Docker makes it easy to run the application without installing Python dependencies locally.

#### Quick Start with Docker Compose

1. Clone this repository:
```bash
git clone https://github.com/Sivareddy6244/excel_and_zip_flies_data_versioning.git
cd excel_and_zip_flies_data_versioning
```

2. Run with Docker Compose:
```bash
docker-compose up --build
```

3. Open your web browser and go to:
```
http://localhost:5001
```

4. To stop the application:
```bash
docker-compose down
```

#### Alternative: Using Docker Commands

1. Build the Docker image:
```bash
docker build -t excel-zip-versioning .
```

2. Run the container:
```bash
docker run -d -p 5001:5001 -v $(pwd):/app --name excel-versioning excel-zip-versioning
```

3. Access the application at `http://localhost:5001`

4. To stop and remove the container:
```bash
docker stop excel-versioning
docker rm excel-versioning
```

#### Docker Notes
- The application runs on port 5001 by default
- The current directory is mounted as a volume to `/app` in the container
- This allows the application to access your Git repository and files
- Environment variables can be configured in `docker-compose.yml`

### Option 2: Using Python Directly

1. Clone this repository:
```bash
git clone https://github.com/Sivareddy6244/excel_and_zip_flies_data_versioning.git
cd excel_and_zip_flies_data_versioning
```

2. Install required dependencies:
```bash
pip install -r requirements.txt
```

3. Run the Flask application:
```bash
python app.py
```

4. Open your web browser and go to:
```
http://localhost:5001
```

## How to Use the Web Interface

### Connecting to a GitHub Repository

The application supports two modes:

1. **Local Repository Mode** (Default): Uses the local Git repository where the application is running
2. **GitHub Repository Mode**: Connect to any remote GitHub repository

#### To Connect to a GitHub Repository:

1. Open the application at `http://localhost:5001`
2. In the **GitHub Repository Connection** section:
   - Enter the full GitHub repository URL (e.g., `https://github.com/username/repository`)
   - Optionally, provide a Personal Access Token for private repositories
   - Click **"Connect to GitHub"**
3. The application will clone the repository and load its commits and files

#### To Generate a GitHub Personal Access Token:

1. Visit [GitHub Settings > Tokens](https://github.com/settings/tokens)
2. Click "Generate new token (classic)"
3. Select scopes: `repo` (for private repos) or `public_repo` (for public repos only)
4. Copy the generated token and paste it in the application

#### To Switch Back to Local Repository:

- Click the **"Use Local Repository"** button

### Comparing Files

1. **Select File**: Choose an Excel or ZIP file from the dropdown
2. **First Commit**: Select the older commit you want to compare from
3. **Second Commit**: Select the newer commit you want to compare to
4. Click **"Compare Commits"** to see the differences

## What Gets Compared

### Excel Files
- Sheet additions and removals
- Row count changes
- Cell-by-cell data changes
- Column additions and removals

### ZIP Files
- File additions and removals
- File size changes
- Content changes (for text files)
- Directory structure changes

## Example Use Case

Imagine you have an Excel file `data.xlsx` in your repository:

1. **Commit 1**: You add the initial version with some data
2. **Commit 2**: You update some cells and add a new sheet
3. **Using this tool**: Select `data.xlsx`, choose Commit 1 and Commit 2, and see exactly what changed:
   - "Sheet 'Summary' was added"
   - "Sheet 'Data', Row 5, Column 'Price': '100' → '120'"
   - And more...

## API Endpoints

The application provides the following REST API endpoints:

- `GET /api/commits` - Returns list of all commits
- `GET /api/files?commit=<hash>` - Returns Excel/ZIP files at a specific commit
- `POST /api/compare` - Compares a file between two commits

## Troubleshooting

**No files showing up?**
- Make sure your repository contains .xlsx, .xls, or .zip files
- Ensure you have at least one commit in your repository

**Comparison failing?**
- Verify that the selected file exists in both commits
- Check that the Excel file is not corrupted
- Ensure the ZIP file is valid

## Technical Details

- **Backend**: Flask (Python web framework)
- **Excel Processing**: pandas and openpyxl
- **ZIP Processing**: Built-in zipfile module
- **Version Control**: Git command-line interface
- **Frontend**: HTML, CSS, JavaScript (Vanilla)
- **Containerization**: Docker and Docker Compose

## Docker Configuration

The application includes the following Docker files:

- **Dockerfile**: Defines the container image with Python 3.11, Git, and all dependencies
- **docker-compose.yml**: Orchestrates the container setup with volume mounts and port mapping
- **.dockerignore**: Excludes unnecessary files from the Docker build context

### Environment Variables

You can configure the following environment variables:

- `FLASK_DEBUG`: Set to `true` for debug mode, `false` for production (default: `false`)
- Port mapping: Default is `5001:5001`, can be changed in `docker-compose.yml`

## License

This project is open source and available for educational and commercial use.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.