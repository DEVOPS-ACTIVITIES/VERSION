import { useState } from 'react'
import { PrimeReactProvider } from 'primereact/api'
import LandingPage from './components/LandingPage'
import GCSFlow from './components/GCSFlow'
import GitHubFlow from './components/GitHubFlow'

export default function App() {
  const [source, setSource] = useState(null) // 'gcs' | 'github'

  return (
    <PrimeReactProvider value={{ ripple: true }}>
      <div className={source ? 'app-wrapper app-wrapper--fullscreen' : 'app-wrapper'}>
        {!source && <LandingPage onSelect={setSource} />}
        {source === 'gcs' && <GCSFlow onBack={() => setSource(null)} />}
        {source === 'github' && <GitHubFlow onBack={() => setSource(null)} />}
      </div>
    </PrimeReactProvider>
  )
}
