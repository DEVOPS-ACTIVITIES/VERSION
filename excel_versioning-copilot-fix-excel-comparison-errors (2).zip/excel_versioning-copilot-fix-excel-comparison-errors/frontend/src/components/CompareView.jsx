import React from 'react'
import { TabView, TabPanel } from 'primereact/tabview'
import { Badge } from 'primereact/badge'
import { Tag } from 'primereact/tag'
import { Accordion, AccordionTab } from 'primereact/accordion'
import { Message } from 'primereact/message'

// LCS-based diff helper — works on an array of tokens (chars or words)
function lcsDiff(oldTokens, newTokens) {
  const m = oldTokens.length
  const n = newTokens.length
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0))
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = oldTokens[i - 1] === newTokens[j - 1]
        ? dp[i - 1][j - 1] + 1
        : Math.max(dp[i - 1][j], dp[i][j - 1])
    }
  }
  const result = []
  let i = m, j = n
  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && oldTokens[i - 1] === newTokens[j - 1]) {
      result.unshift({ type: 'unchanged', text: oldTokens[i - 1] })
      i--; j--
    } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
      result.unshift({ type: 'added', text: newTokens[j - 1] })
      j--
    } else {
      result.unshift({ type: 'removed', text: oldTokens[i - 1] })
      i--
    }
  }
  // Merge consecutive same-type tokens into runs
  return result.reduce((acc, part) => {
    if (acc.length > 0 && acc[acc.length - 1].type === part.type) {
      acc[acc.length - 1] = { type: part.type, text: acc[acc.length - 1].text + part.text }
    } else {
      acc.push({ type: part.type, text: part.text })
    }
    return acc
  }, [])
}

// Character-level diff — highlights individual added/removed characters
function charDiff(oldStr, newStr) {
  return lcsDiff(oldStr.split(''), newStr.split(''))
}

// Word-level diff (fallback for very long strings)
function wordDiff(oldStr, newStr) {
  return lcsDiff(oldStr.split(/(\s+)/), newStr.split(/(\s+)/))
}

// Pick char-level diff for short strings, word-level for long ones
function cellDiff(oldStr, newStr) {
  const oldValue = String(oldStr ?? '')
  const newValue = String(newStr ?? '')
  if (oldValue === newValue) return [{ type: 'unchanged', text: oldValue }]
  return (oldValue.length + newValue.length <= 400) ? charDiff(oldValue, newValue) : wordDiff(oldValue, newValue)
}

function DiffCell({ oldVal, newVal, showOld }) {
  const oldValue = String(oldVal ?? '')
  const newValue = String(newVal ?? '')
  const parts = cellDiff(oldValue, newValue)
  if (oldValue === newValue) {
    return <span>{oldValue}</span>
  }
  return (
    <span>
      {parts.map((part, idx) => {
        if (part.type === 'unchanged') return <span key={idx}>{part.text}</span>
        if (part.type === 'added' && !showOld) return <span key={idx} className="word-added">{part.text}</span>
        if (part.type === 'removed' && showOld) return <span key={idx} className="word-removed">{part.text}</span>
        return null
      })}
    </span>
  )
}

/**
 * Pre-process diff_lines: the backend now emits 'changed' entries directly for
 * modified rows.  This function also handles any legacy consecutive removed+added
 * pairs (e.g. from older cached responses) by converting them to 'changed' entries.
 */
function pairDiffLines(diffLines) {
  const result = []
  let i = 0
  while (i < diffLines.length) {
    const line = diffLines[i]
    if (line.type === 'removed' && i + 1 < diffLines.length && diffLines[i + 1].type === 'added') {
      // Legacy: consecutive removed+added → changed
      const next = diffLines[i + 1]
      result.push({
        type: 'changed',
        old_line_num: line.old_line_num,
        new_line_num: next.new_line_num,
        old_cells: line.cells || [],
        new_cells: next.cells || [],
      })
      i += 2
    } else {
      result.push(line)
      i++
    }
  }
  return result
}

/** Render a table of rows for added/removed sheets */
function SheetDataTable({ columns, rows, isAdded }) {
  if (!rows || rows.length === 0) return null
  const rowBg = isAdded ? '#e6ffec' : '#ffebe9'
  return (
    <div style={{ overflowX: 'auto', borderRadius: '0 0 10px 10px', border: '1px solid #e2e8f0', borderTop: 'none' }}>
      <table className="diff-table">
        <thead>
          <tr>
            <th style={{ width: '40px', background: '#f1f5f9' }}>#</th>
            {columns.map(col => <th key={col}>{col}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, rIdx) => (
            <tr key={rIdx} style={{ background: rowBg }}>
              <td style={{ color: '#94a3b8', fontSize: '0.8rem', background: rowBg }}>{rIdx + 1}</td>
              {columns.map((col, cIdx) => (
                <td key={cIdx} style={{ background: rowBg }}>
                  {row[col] !== null && row[col] !== undefined ? String(row[col]) : ''}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}

function ExcelDiff({ differences }) {
  if (!differences || differences.length === 0) {
    return (
      <Message severity="success" text="No differences found between the two versions." className="w-full" />
    )
  }

  return (
    <div>
      {differences.map((diff, idx) => {
        if (diff.type === 'sheet_added') {
          return (
            <div key={idx} className="mb-4">
              <div style={{
                background: '#e6ffec', border: '2px solid #38a169',
                borderRadius: diff.rows && diff.rows.length > 0 ? '10px 10px 0 0' : '10px',
                padding: '10px 16px', display: 'flex', alignItems: 'center', gap: '10px'
              }}>
                <Tag severity="success" value="✚ SHEET ADDED" style={{ fontWeight: 700 }} />
                <span style={{ fontWeight: 700, fontSize: '1rem', color: '#333' }}>{diff.sheet}</span>
                {diff.rows && <span style={{ color: '#888', fontSize: '0.85rem' }}>({diff.rows.length} rows)</span>}
              </div>
              {diff.columns && diff.rows && diff.rows.length > 0 && (
                <SheetDataTable columns={diff.columns} rows={diff.rows} isAdded={true} />
              )}
            </div>
          )
        }
        if (diff.type === 'sheet_removed') {
          return (
            <div key={idx} className="mb-4">
              <div style={{
                background: '#ffebe9', border: '2px solid #e53e3e',
                borderRadius: diff.rows && diff.rows.length > 0 ? '10px 10px 0 0' : '10px',
                padding: '10px 16px', display: 'flex', alignItems: 'center', gap: '10px'
              }}>
                <Tag severity="danger" value="✖ SHEET REMOVED" style={{ fontWeight: 700 }} />
                <span style={{ fontWeight: 700, fontSize: '1rem', color: '#333' }}>{diff.sheet}</span>
                {diff.rows && <span style={{ color: '#888', fontSize: '0.85rem' }}>({diff.rows.length} rows)</span>}
              </div>
              {diff.columns && diff.rows && diff.rows.length > 0 && (
                <SheetDataTable columns={diff.columns} rows={diff.rows} isAdded={false} />
              )}
            </div>
          )
        }
        if (diff.type === 'sheet_table_diff') {
          const columns = diff.columns || []
          const rawLines = diff.diff_lines || []

          // Pair consecutive removed+added lines for word-level diff (backend
          // already emits 'changed' entries directly; this handles legacy data)
          const diffLines = pairDiffLines(rawLines)

          const added = rawLines.filter(l => l.type === 'added').length
          const removed = rawLines.filter(l => l.type === 'removed').length
          const modified = rawLines.filter(l => l.type === 'changed').length

          return (
            <div key={idx} className="mb-5">
              {/* Sheet header with MODIFIED badge */}
              <div className="flex align-items-center gap-3 mb-2 p-3 border-round"
                style={{ background: '#fff3e0', border: '2px solid #ff9800', borderRadius: '10px 10px 0 0' }}>
                <Tag value="✎ MODIFIED" style={{ background: '#ff9800', color: '#fff', fontWeight: 700 }} />
                <h4 style={{ margin: 0, color: '#1e293b', fontSize: '1rem' }}>
                  <i className="pi pi-table mr-2" style={{ color: '#6366f1' }}></i>
                  Sheet: <strong>{diff.sheet}</strong>
                </h4>
                <div className="flex gap-2">
                  {modified > 0 && (
                    <Tag severity="warning" value={`~${modified} modified`} style={{ fontWeight: 700 }} />
                  )}
                  {added > 0 && (
                    <Tag severity="success" value={`+${added} added`} style={{ fontWeight: 700 }} />
                  )}
                  {removed > 0 && (
                    <Tag severity="danger" value={`−${removed} removed`} style={{ fontWeight: 700 }} />
                  )}
                </div>
              </div>

              {diffLines.length === 0 ? (
                <Message severity="info" text="Columns differ but no row changes." />
              ) : (
                <div style={{ overflowX: 'auto', borderRadius: '0 0 10px 10px', border: '1px solid #e2e8f0' }}>
                  <table className="diff-table">
                    <thead>
                      <tr>
                        <th style={{ width: '40px' }}>#</th>
                        <th style={{ width: '80px' }}>Change</th>
                        {columns.map(col => (
                          <th key={col}>{col}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {diffLines.map((line, lIdx) => {
                        const isChanged = line.type === 'changed'
                        const isAdded = line.type === 'added'
                        const isRemoved = line.type === 'removed'

                        if (isChanged) {
                          // Show old row (red) and new row (green) side-by-side with word diff
                          return (
                            <>
                              <tr key={`${lIdx}-old`} className="diff-row-removed">
                                <td style={{ color: '#94a3b8', fontSize: '0.8rem', background: '#ffebe9' }}>
                                  {line.old_line_num ?? ''}
                                </td>
                                <td style={{ background: '#ffebe9' }}>
                                  <Tag severity="danger" value="−" style={{ fontWeight: 700 }} />
                                </td>
                                {columns.map((col, cIdx) => (
                                  <td key={cIdx} style={{ background: '#ffebe9' }}>
                                    <DiffCell
                                      oldVal={line.old_cells[cIdx] ?? ''}
                                      newVal={line.new_cells[cIdx] ?? ''}
                                      showOld={true}
                                    />
                                  </td>
                                ))}
                              </tr>
                              <tr key={`${lIdx}-new`} className="diff-row-added">
                                <td style={{ color: '#94a3b8', fontSize: '0.8rem', background: '#e6ffec' }}>
                                  {line.new_line_num ?? ''}
                                </td>
                                <td style={{ background: '#e6ffec' }}>
                                  <Tag severity="success" value="+" style={{ fontWeight: 700 }} />
                                </td>
                                {columns.map((col, cIdx) => (
                                  <td key={cIdx} style={{ background: '#e6ffec' }}>
                                    <DiffCell
                                      oldVal={line.old_cells[cIdx] ?? ''}
                                      newVal={line.new_cells[cIdx] ?? ''}
                                      showOld={false}
                                    />
                                  </td>
                                ))}
                              </tr>
                            </>
                          )
                        }

                        const cells = isAdded ? (line.cells || []) : (line.cells || [])
                        const rowBg = isAdded ? '#e6ffec' : '#ffebe9'
                        const badge = isAdded ? (
                          <Tag severity="success" value="+" style={{ fontWeight: 700 }} />
                        ) : isRemoved ? (
                          <Tag severity="danger" value="−" style={{ fontWeight: 700 }} />
                        ) : null

                        return (
                          <tr key={lIdx}>
                            <td style={{ color: '#94a3b8', fontSize: '0.8rem', background: rowBg }}>
                              {line.new_line_num ?? line.old_line_num ?? lIdx + 1}
                            </td>
                            <td style={{ background: rowBg }}>{badge}</td>
                            {columns.map((col, cIdx) => (
                              <td key={cIdx} style={{ background: rowBg }}>
                                {String(cells[cIdx] ?? '')}
                              </td>
                            ))}
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )
        }
        return null
      })}
    </div>
  )
}

function ZipDiff({ differences }) {
  if (!differences || differences.length === 0) {
    return (
      <Message severity="success" text="No differences found between the two versions." className="w-full" />
    )
  }

  return (
    <div>
      {differences.map((diff, idx) => {
        if (diff.type === 'file_added') {
          return (
            <div key={idx} className="mb-3 p-3 border-round flex align-items-center gap-3"
              style={{ background: '#f0fdf4', border: '1px solid #bbf7d0' }}>
              <Tag severity="success" value="ADDED" />
              <span style={{ fontFamily: 'monospace', color: '#166534' }}>{diff.filename || diff.file}</span>
            </div>
          )
        }
        if (diff.type === 'file_removed') {
          return (
            <div key={idx} className="mb-3 p-3 border-round flex align-items-center gap-3"
              style={{ background: '#fff5f5', border: '1px solid #fecaca' }}>
              <Tag severity="danger" value="REMOVED" />
              <span style={{ fontFamily: 'monospace', color: '#991b1b' }}>{diff.filename || diff.file}</span>
            </div>
          )
        }
        if (diff.type === 'file_size_change') {
          return (
            <div key={idx} className="mb-3 p-3 border-round flex align-items-center gap-3"
              style={{ background: '#fffbeb', border: '1px solid #fde68a' }}>
              <Tag severity="warning" value="SIZE CHANGED" />
              <span style={{ fontFamily: 'monospace', color: '#92400e' }}>{diff.filename || diff.file}</span>
              <span style={{ color: '#64748b', fontSize: '0.85rem' }}>
                {diff.old_size != null ? `${diff.old_size.toLocaleString()} → ${diff.new_size.toLocaleString()} bytes` : diff.message}
              </span>
            </div>
          )
        }
        // Handle both 'content_change_lines' (backend) and legacy 'file_changed' type
        if (diff.type === 'content_change_lines' || diff.type === 'file_changed') {
          const lineChanges = diff.line_changes || diff.diff_lines || []
          const filename = diff.filename || diff.file || ''
          const isSampled = diff.is_sampled || false
          const added = lineChanges.filter(l => l.type === 'added').length
          const removed = lineChanges.filter(l => l.type === 'removed').length
          return (
            <Accordion key={idx} className="mb-3">
              <AccordionTab
                header={
                  <div className="flex align-items-center gap-3 flex-wrap">
                    <Tag severity="warning" value="CHANGED" />
                    <span style={{ fontFamily: 'monospace' }}>{filename}</span>
                    {added > 0 && <Tag severity="success" value={`+${added} added`} style={{ fontWeight: 700 }} />}
                    {removed > 0 && <Tag severity="danger" value={`−${removed} removed`} style={{ fontWeight: 700 }} />}
                    {isSampled && <Tag severity="info" value="truncated" style={{ fontWeight: 700 }} />}
                    {diff.old_size != null && (
                      <span style={{ color: '#94a3b8', fontSize: '0.8rem' }}>
                        {(diff.old_size / (1024 * 1024)).toFixed(2)} MB → {(diff.new_size / (1024 * 1024)).toFixed(2)} MB
                      </span>
                    )}
                  </div>
                }
              >
                {lineChanges.length > 0 ? (
                  <div style={{ background: '#1e1e1e', borderRadius: '8px', padding: '16px', overflowX: 'auto', maxHeight: '600px', overflowY: 'auto' }}>
                    {lineChanges.map((line, lIdx) => {
                      const color = line.type === 'added' ? '#86efac' : line.type === 'removed' ? '#fca5a5' : '#e2e8f0'
                      const bg = line.type === 'added' ? 'rgba(134,239,172,0.1)' : line.type === 'removed' ? 'rgba(252,165,165,0.1)' : 'transparent'
                      const prefix = line.type === 'added' ? '+' : line.type === 'removed' ? '-' : ' '
                      const lineNum = line.new_line_num || line.old_line_num || ''
                      return (
                        <div key={lIdx} style={{
                          fontFamily: 'monospace',
                          fontSize: '0.85rem',
                          color,
                          background: bg,
                          padding: '2px 8px',
                          borderRadius: '3px',
                          marginBottom: '1px',
                          display: 'flex',
                          gap: '8px',
                        }}>
                          <span style={{ opacity: 0.4, minWidth: '48px', textAlign: 'right', userSelect: 'none' }}>{lineNum}</span>
                          <span style={{ opacity: 0.6, userSelect: 'none' }}>{prefix}</span>
                          <span style={{ whiteSpace: 'pre-wrap', wordBreak: 'break-all' }}>{line.text || line.content || ''}</span>
                        </div>
                      )
                    })}
                    {isSampled && (
                      <div style={{ color: '#94a3b8', fontFamily: 'monospace', fontSize: '0.85rem', padding: '8px', textAlign: 'center' }}>
                        … diff truncated – showing first 5,000 changed lines …
                      </div>
                    )}
                  </div>
                ) : (
                  <Message severity="info" text="Binary file or no text diff available." />
                )}
              </AccordionTab>
            </Accordion>
          )
        }
        return null
      })}
    </div>
  )
}

export default function CompareView({ result, newerLabel, olderLabel }) {
  if (!result) return null

  const { file_type, differences, total_changes, size1_mb, size2_mb } = result

  const rowAdded = differences?.reduce((sum, d) =>
    sum + (d.diff_lines?.filter(l => l.type === 'added').length || 0) +
    (d.type === 'sheet_added' ? (d.rows?.length || 0) : 0), 0) || 0
  const rowRemoved = differences?.reduce((sum, d) =>
    sum + (d.diff_lines?.filter(l => l.type === 'removed').length || 0) +
    (d.type === 'sheet_removed' ? (d.rows?.length || 0) : 0), 0) || 0
  const rowModified = differences?.reduce((sum, d) =>
    sum + (d.diff_lines?.filter(l => l.type === 'changed').length || 0), 0) || 0
  const sheetsAdded = differences?.filter(d => d.type === 'sheet_added').length || 0
  const sheetsRemoved = differences?.filter(d => d.type === 'sheet_removed').length || 0
  const sheetsModified = differences?.filter(d => d.type === 'sheet_table_diff').length || 0

  return (
    <div className="animate-fade-in">
      {/* Version comparison header */}
      <div className="flex align-items-center justify-content-between mb-4 p-3 border-round"
        style={{ background: '#f8fafc', border: '1px solid #e2e8f0' }}>
        <div className="flex align-items-center gap-2">
          <span className="version-badge version-older">
            <i className="pi pi-history"></i>
            Older: {olderLabel}
          </span>
          <i className="pi pi-arrow-right" style={{ color: '#94a3b8' }}></i>
          <span className="version-badge version-newer">
            <i className="pi pi-star-fill"></i>
            Newer: {newerLabel}
          </span>
        </div>
        <div className="flex gap-3 text-sm" style={{ color: '#64748b' }}>
          <span><i className="pi pi-box mr-1"></i>{size1_mb} MB → {size2_mb} MB</span>
        </div>
      </div>

      {/* Stats bar - green/red theme */}
      <div className="stats-bar mb-4">
        {rowModified > 0 && (
          <div className="stat-item">
            <div className="stat-dot" style={{ background: '#f59e0b' }}></div>
            <span style={{ color: '#92400e', fontWeight: 600 }}>{rowModified} row{rowModified !== 1 ? 's' : ''} modified</span>
          </div>
        )}
        {rowAdded > 0 && (
          <>
            {rowModified > 0 && <div className="stat-dot" style={{ background: '#e2e8f0', width: '1px', height: '20px' }}></div>}
            <div className="stat-item">
              <div className="stat-dot" style={{ background: '#22c55e' }}></div>
              <span style={{ color: '#166534', fontWeight: 600 }}>{rowAdded} row{rowAdded !== 1 ? 's' : ''} added</span>
            </div>
          </>
        )}
        {rowRemoved > 0 && (
          <>
            {(rowModified > 0 || rowAdded > 0) && <div className="stat-dot" style={{ background: '#e2e8f0', width: '1px', height: '20px' }}></div>}
            <div className="stat-item">
              <div className="stat-dot" style={{ background: '#ef4444' }}></div>
              <span style={{ color: '#991b1b', fontWeight: 600 }}>{rowRemoved} row{rowRemoved !== 1 ? 's' : ''} removed</span>
            </div>
          </>
        )}
        {sheetsAdded > 0 && (
          <>
            <div className="stat-dot" style={{ background: '#e2e8f0', width: '1px', height: '20px' }}></div>
            <div className="stat-item">
              <div className="stat-dot" style={{ background: '#22c55e' }}></div>
              <span style={{ color: '#166534', fontWeight: 600 }}>{sheetsAdded} sheet{sheetsAdded !== 1 ? 's' : ''} added</span>
            </div>
          </>
        )}
        {sheetsRemoved > 0 && (
          <>
            <div className="stat-dot" style={{ background: '#e2e8f0', width: '1px', height: '20px' }}></div>
            <div className="stat-item">
              <div className="stat-dot" style={{ background: '#ef4444' }}></div>
              <span style={{ color: '#991b1b', fontWeight: 600 }}>{sheetsRemoved} sheet{sheetsRemoved !== 1 ? 's' : ''} removed</span>
            </div>
          </>
        )}
        {sheetsModified > 0 && (
          <>
            <div className="stat-dot" style={{ background: '#e2e8f0', width: '1px', height: '20px' }}></div>
            <div className="stat-item">
              <div className="stat-dot" style={{ background: '#f59e0b' }}></div>
              <span style={{ color: '#92400e', fontWeight: 600 }}>{sheetsModified} sheet{sheetsModified !== 1 ? 's' : ''} modified</span>
            </div>
          </>
        )}
        <div className="ml-auto" style={{ color: '#64748b', fontSize: '0.875rem' }}>
          <i className="pi pi-chart-bar mr-1"></i>
          {total_changes} total differences
        </div>
      </div>

      {/* Diff content */}
      {file_type === 'excel' ? (
        <ExcelDiff differences={differences} />
      ) : (
        <ZipDiff differences={differences} />
      )}
    </div>
  )
}
