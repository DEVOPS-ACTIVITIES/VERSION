import { useState } from 'react'
import axios from 'axios'
import { Button } from 'primereact/button'
import { InputText } from 'primereact/inputtext'
import { Password } from 'primereact/password'
import { ProgressSpinner } from 'primereact/progressspinner'
import { Message } from 'primereact/message'
import { Dropdown } from 'primereact/dropdown'
import { Tag } from 'primereact/tag'
import { Divider } from 'primereact/divider'
import { Timeline } from 'primereact/timeline'
import { Chip } from 'primereact/chip'
import CompareView from './CompareView'

const STEPS = ['Connect', 'Branch', 'Select File', 'Choose Commits', 'Compare']

function StepProgress({ current }) {
  return (
    <div className="progress-steps">
      {STEPS.map((label, idx) => {
        const state = idx < current ? 'completed' : idx === current ? 'active' : 'pending'
        return (
          <div key={idx} className="flex align-items-center" style={{ flex: 1 }}>
            <div className="progress-step" style={{ flex: 0 }}>
              <div className={`progress-step-circle ${state}`}>
                {state === 'completed' ? <i className="pi pi-check" style={{ fontSize: '0.8rem' }}></i> : idx + 1}
              </div>
              <span className={`progress-step-label ${state === 'active' ? 'active' : ''}`}>{label}</span>
            </div>
            {idx < STEPS.length - 1 && (
              <div className={`progress-connector ${state === 'completed' ? 'completed' : ''}`} style={{ flex: 1 }}></div>
            )}
          </div>
        )
      })}
    </div>
  )
}

export default function GitHubFlow({ onBack }) {
  const [step, setStep] = useState(0)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  // Step 0
  const [repoUrl, setRepoUrl] = useState('')
  const [token, setToken] = useState('')

  // Step 1
  const [branches, setBranches] = useState([])
  const [selectedBranch, setSelectedBranch] = useState(null)

  // Step 2
  const [files, setFiles] = useState([])
  const [selectedFile, setSelectedFile] = useState(null)

  // Step 3
  const [commits, setCommits] = useState([])
  const [newerCommit, setNewerCommit] = useState(null)
  const [olderCommit, setOlderCommit] = useState(null)

  // Step 4
  const [compareResult, setCompareResult] = useState(null)
  const [comparing, setComparing] = useState(false)

  const handleConnect = async () => {
    if (!repoUrl.trim()) { setError('Repository URL is required'); return }
    setLoading(true); setError('')
    try {
      await axios.post('/api/config/github', { github_url: repoUrl, token })
      const res = await axios.get('/api/branches')
      setBranches(res.data)
      setStep(1)
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to connect to GitHub')
    } finally {
      setLoading(false)
    }
  }

  const handleSelectBranch = async (branch) => {
    setSelectedBranch(branch)
    setLoading(true); setError(''); setFiles([])
    try {
      const res = await axios.get('/api/files', { params: { branch } })
      setFiles(res.data)
      setStep(2)
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to load files')
    } finally {
      setLoading(false)
    }
  }

  const handleSelectFile = async (file) => {
    setSelectedFile(file)
    setLoading(true); setError(''); setCommits([])
    try {
      const res = await axios.get('/api/commits', { params: { branch: selectedBranch, file } })
      const cs = res.data
      setCommits(cs)
      if (cs.length > 0) {
        setNewerCommit(cs[0])
        setOlderCommit(cs.length > 1 ? cs[1] : cs[0])
      }
      setStep(3)
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to load commits')
    } finally {
      setLoading(false)
    }
  }

  const handleCompare = async () => {
    if (!newerCommit || !olderCommit) { setError('Please select both commits'); return }
    setComparing(true); setError(''); setCompareResult(null)
    try {
      const res = await axios.post('/api/compare', {
        file: selectedFile,
        commit1: olderCommit.hash,
        commit2: newerCommit.hash,
      })
      setCompareResult(res.data)
      setStep(4)
    } catch (e) {
      setError(e.response?.data?.error || 'Comparison failed')
    } finally {
      setComparing(false)
    }
  }

  const getFileIcon = (filename) => {
    if (filename.endsWith('.xlsx') || filename.endsWith('.xls')) return 'pi pi-file-excel'
    if (filename.endsWith('.zip')) return 'pi pi-box'
    return 'pi pi-file'
  }

  const getFileColor = (filename) => {
    if (filename.endsWith('.xlsx') || filename.endsWith('.xls')) return '#16a34a'
    if (filename.endsWith('.zip')) return '#ea580c'
    return '#6366f1'
  }

  const formatDate = (ts) => {
    if (!ts) return ''
    try { return new Date(ts).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) }
    catch { return ts }
  }

  const shortHash = (hash) => hash ? hash.substring(0, 7) : ''

  const commitOptionTemplate = (c) => c ? (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '2px' }}>
      <div style={{ fontWeight: 600, fontSize: '0.85rem' }}>
        <span style={{ fontFamily: 'monospace', background: '#f1f5f9', padding: '1px 6px', borderRadius: '4px', marginRight: '8px' }}>
          {shortHash(c.hash)}
        </span>
        {c.message?.split('\n')[0]?.slice(0, 60) || 'No message'}
      </div>
      <div style={{ fontSize: '0.75rem', color: '#94a3b8' }}>
        <i className="pi pi-user mr-1"></i>{c.author} · {formatDate(c.date)}
      </div>
    </div>
  ) : null

  const commitValueTemplate = (c) => c ? (
    <span style={{ fontSize: '0.9rem' }}>
      <span style={{ fontFamily: 'monospace', background: '#f1f5f9', padding: '1px 6px', borderRadius: '4px', marginRight: '6px' }}>
        {shortHash(c.hash)}
      </span>
      {c.message?.split('\n')[0]?.slice(0, 40) || 'No message'}
    </span>
  ) : 'Select commit'

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
      <div className="glass-card glass-card--fullscreen animate-fade-in">
        {/* Header */}
        <div className="hero-gradient" style={{ background: 'linear-gradient(135deg, #24292e 0%, #6e40c9 100%)' }}>
          <div className="flex align-items-center justify-content-between">
            <Button
              icon="pi pi-arrow-left"
              label="Back"
              className="p-button-text p-button-sm"
              style={{ color: 'white', border: '1px solid rgba(255,255,255,0.3)' }}
              onClick={onBack}
            />
            <div className="text-center flex-1">
              <div style={{ fontSize: '2rem', marginBottom: '4px' }}>
                <i className="pi pi-github" style={{ marginRight: '12px' }}></i>
                GitHub Repository
              </div>
              <div style={{ opacity: 0.8, fontSize: '0.9rem' }}>Compare Excel & ZIP files between commits</div>
            </div>
            <div style={{ width: '80px' }}></div>
          </div>
        </div>

        <div className="p-5" style={{ maxWidth: '1400px', width: '100%', margin: '0 auto', flex: 1 }}>
          <StepProgress current={step} />

          {error && (
            <Message severity="error" text={error} className="w-full mb-4" />
          )}

          {/* Step 0: Connect */}
          {step === 0 && (
            <div className="animate-fade-in">
              <div className="flex flex-column gap-4" style={{ maxWidth: '600px', margin: '0 auto' }}>
                <div className="step-indicator mb-2">
                  <i className="pi pi-github"></i>
                  Step 1: Connect to GitHub Repository
                </div>
                <div className="flex flex-column gap-2">
                  <label className="font-semibold" style={{ color: '#374151' }}>
                    <i className="pi pi-link mr-2" style={{ color: '#6e40c9' }}></i>
                    Repository URL <span style={{ color: '#ef4444' }}>*</span>
                  </label>
                  <InputText
                    value={repoUrl}
                    onChange={e => setRepoUrl(e.target.value)}
                    placeholder="https://github.com/owner/repo"
                    onKeyDown={e => e.key === 'Enter' && handleConnect()}
                    style={{ borderRadius: '10px' }}
                  />
                </div>
                <div className="flex flex-column gap-2">
                  <label className="font-semibold" style={{ color: '#374151' }}>
                    <i className="pi pi-key mr-2" style={{ color: '#6e40c9' }}></i>
                    Personal Access Token <span style={{ color: '#94a3b8', fontSize: '0.85rem' }}>(optional, for private repos)</span>
                  </label>
                  <Password
                    value={token}
                    onChange={e => setToken(e.target.value)}
                    placeholder="ghp_xxxx..."
                    feedback={false}
                    toggleMask
                    inputStyle={{ borderRadius: '10px', width: '100%' }}
                    style={{ width: '100%' }}
                  />
                  <small style={{ color: '#94a3b8' }}>
                    <i className="pi pi-shield mr-1"></i>
                    Token is used only for authentication and never stored
                  </small>
                </div>
                <Button
                  label={loading ? 'Connecting...' : 'Connect to Repository'}
                  icon={loading ? 'pi pi-spin pi-spinner' : 'pi pi-github'}
                  disabled={loading}
                  onClick={handleConnect}
                  style={{
                    background: 'linear-gradient(135deg, #24292e 0%, #6e40c9 100%)',
                    border: 'none',
                    borderRadius: '10px',
                    padding: '12px',
                    fontWeight: '600',
                    fontSize: '1rem'
                  }}
                />
              </div>
            </div>
          )}

          {/* Step 1: Branch Selection */}
          {step >= 1 && (
            <div className="animate-fade-in">
              <div className="step-indicator mb-4">
                <i className="pi pi-code-branch"></i>
                Step 2: Select a branch
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: '10px' }}>
                {branches.map((branch, idx) => (
                  <div
                    key={idx}
                    onClick={() => step >= 1 && handleSelectBranch(branch)}
                    style={{
                      padding: '12px 16px',
                      borderRadius: '10px',
                      cursor: 'pointer',
                      border: '2px solid',
                      borderColor: selectedBranch === branch ? '#6366f1' : '#e2e8f0',
                      background: selectedBranch === branch ? '#eef2ff' : '#f8fafc',
                      transition: 'all 0.2s',
                      display: 'flex',
                      alignItems: 'center',
                      gap: '10px'
                    }}
                  >
                    <i className="pi pi-code-branch" style={{ color: selectedBranch === branch ? '#6366f1' : '#94a3b8' }}></i>
                    <span style={{
                      fontWeight: '600',
                      color: selectedBranch === branch ? '#4338ca' : '#374151',
                      fontSize: '0.9rem'
                    }}>{branch}</span>
                    {branch === 'main' || branch === 'master' ? (
                      <Tag value="default" severity="info" style={{ marginLeft: 'auto', fontSize: '0.7rem' }} />
                    ) : null}
                  </div>
                ))}
              </div>
              {loading && step === 1 && (
                <div className="flex justify-content-center mt-4">
                  <ProgressSpinner style={{ width: '40px', height: '40px' }} />
                </div>
              )}
            </div>
          )}

          {/* Step 2: File Selection */}
          {step >= 2 && (
            <div className="animate-fade-in mt-5">
              <Divider />
              <div className="step-indicator mb-4">
                <i className="pi pi-folder-open"></i>
                Step 3: Select a file to compare
              </div>
              {loading && step === 2 ? (
                <div className="flex justify-content-center">
                  <ProgressSpinner style={{ width: '40px', height: '40px' }} />
                </div>
              ) : (
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '12px' }}>
                  {files.map((file, idx) => (
                    <div
                      key={idx}
                      className={`file-card p-3 border-round`}
                      style={{
                        background: selectedFile === file ? '#eef2ff' : '#f8fafc',
                        border: '2px solid',
                        borderColor: selectedFile === file ? '#6366f1' : '#e2e8f0',
                        cursor: 'pointer'
                      }}
                      onClick={() => handleSelectFile(file)}
                    >
                      <div className="flex align-items-center gap-3">
                        <div style={{
                          width: '40px', height: '40px', borderRadius: '10px',
                          background: selectedFile === file ? '#6366f1' : '#f1f5f9',
                          display: 'flex', alignItems: 'center', justifyContent: 'center'
                        }}>
                          <i className={getFileIcon(file)} style={{
                            color: selectedFile === file ? 'white' : getFileColor(file),
                            fontSize: '1.2rem'
                          }}></i>
                        </div>
                        <div style={{ overflow: 'hidden' }}>
                          <div style={{
                            fontWeight: '600', fontSize: '0.85rem',
                            color: selectedFile === file ? '#4338ca' : '#1e293b',
                            overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'
                          }}>
                            {file.split('/').pop()}
                          </div>
                          {file.includes('/') && (
                            <div style={{ fontSize: '0.75rem', color: '#94a3b8', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                              {file.split('/').slice(0, -1).join('/')}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  {files.length === 0 && !loading && (
                    <Message severity="info" text="No Excel or ZIP files found in this branch." />
                  )}
                </div>
              )}
            </div>
          )}

          {/* Step 3: Commit Selection */}
          {step >= 3 && (
            <div className="animate-fade-in mt-5">
              <Divider />
              <div className="step-indicator mb-4">
                <i className="pi pi-history"></i>
                Step 4: Choose commits to compare
              </div>
              {loading && step === 3 ? (
                <div className="flex justify-content-center">
                  <ProgressSpinner style={{ width: '40px', height: '40px' }} />
                </div>
              ) : (
                <>
                  <div className="flex gap-4 flex-wrap">
                    <div className="flex flex-column gap-2" style={{ flex: 1, minWidth: '250px' }}>
                      <label className="font-semibold" style={{ color: '#374151' }}>
                        <span className="version-badge version-newer mr-2">Newer Commit</span>
                      </label>
                      <Dropdown
                        value={newerCommit}
                        options={commits}
                        onChange={e => setNewerCommit(e.value)}
                        optionLabel="hash"
                        placeholder="Select newer commit"
                        style={{ borderRadius: '10px' }}
                        itemTemplate={commitOptionTemplate}
                        valueTemplate={commitValueTemplate}
                        panelStyle={{ maxWidth: '500px' }}
                      />
                      <small style={{ color: '#94a3b8' }}>Default: latest commit</small>
                    </div>
                    <div className="flex align-items-center" style={{ paddingTop: '30px' }}>
                      <i className="pi pi-arrows-h" style={{ color: '#94a3b8', fontSize: '1.5rem' }}></i>
                    </div>
                    <div className="flex flex-column gap-2" style={{ flex: 1, minWidth: '250px' }}>
                      <label className="font-semibold" style={{ color: '#374151' }}>
                        <span className="version-badge version-older mr-2">Older Commit</span>
                      </label>
                      <Dropdown
                        value={olderCommit}
                        options={commits}
                        onChange={e => setOlderCommit(e.value)}
                        optionLabel="hash"
                        placeholder="Select older commit"
                        style={{ borderRadius: '10px' }}
                        itemTemplate={commitOptionTemplate}
                        valueTemplate={commitValueTemplate}
                        panelStyle={{ maxWidth: '500px' }}
                      />
                    </div>
                  </div>

                  {/* Commit timeline preview */}
                  {commits.length > 0 && (
                    <div className="mt-4" style={{ maxHeight: '250px', overflowY: 'auto' }}>
                      <div style={{ fontSize: '0.85rem', color: '#64748b', marginBottom: '8px', fontWeight: '600' }}>
                        <i className="pi pi-list mr-1"></i> All commits for this file ({commits.length})
                      </div>
                      {commits.map((c, idx) => (
                        <div
                          key={idx}
                          onClick={() => {
                            if (idx === 0) setNewerCommit(c)
                            else setOlderCommit(c)
                          }}
                          style={{
                            display: 'flex', alignItems: 'flex-start', gap: '12px',
                            padding: '8px 12px', borderRadius: '8px',
                            background: (newerCommit?.hash === c.hash || olderCommit?.hash === c.hash) ? '#eef2ff' : 'transparent',
                            cursor: 'pointer',
                            border: '1px solid',
                            borderColor: (newerCommit?.hash === c.hash || olderCommit?.hash === c.hash) ? '#6366f1' : 'transparent',
                            marginBottom: '4px',
                            transition: 'all 0.15s'
                          }}
                        >
                          <div style={{
                            width: '28px', height: '28px', borderRadius: '50%',
                            background: idx === 0 ? '#dbeafe' : '#f1f5f9',
                            display: 'flex', alignItems: 'center', justifyContent: 'center',
                            flexShrink: 0
                          }}>
                            <i className="pi pi-circle-fill" style={{
                              fontSize: '0.5rem',
                              color: idx === 0 ? '#3b82f6' : '#94a3b8'
                            }}></i>
                          </div>
                          <div style={{ flex: 1, minWidth: 0 }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap' }}>
                              <span style={{
                                fontFamily: 'monospace', fontSize: '0.8rem',
                                background: '#f1f5f9', padding: '1px 6px', borderRadius: '4px',
                                color: '#475569', flexShrink: 0
                              }}>{shortHash(c.hash)}</span>
                              <span style={{ fontSize: '0.875rem', color: '#1e293b', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                                {c.message?.split('\n')[0]?.slice(0, 70) || 'No message'}
                              </span>
                              {idx === 0 && <Tag value="latest" severity="info" style={{ fontSize: '0.7rem', flexShrink: 0 }} />}
                            </div>
                            <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: '2px' }}>
                              <i className="pi pi-user mr-1"></i>{c.author} · {formatDate(c.date)}
                            </div>
                          </div>
                          {(newerCommit?.hash === c.hash || olderCommit?.hash === c.hash) && (
                            <Tag
                              value={newerCommit?.hash === c.hash ? 'newer' : 'older'}
                              severity={newerCommit?.hash === c.hash ? 'info' : 'warning'}
                              style={{ fontSize: '0.7rem', flexShrink: 0 }}
                            />
                          )}
                        </div>
                      ))}
                    </div>
                  )}

                  <Button
                    label={comparing ? 'Comparing...' : 'Compare Commits'}
                    icon={comparing ? 'pi pi-spin pi-spinner' : 'pi pi-code-branch'}
                    disabled={comparing || !newerCommit || !olderCommit}
                    onClick={handleCompare}
                    className="mt-4"
                    style={{
                      background: 'linear-gradient(135deg, #24292e 0%, #6e40c9 100%)',
                      border: 'none',
                      borderRadius: '10px',
                      padding: '12px 32px',
                      fontWeight: '600',
                      fontSize: '1rem'
                    }}
                  />
                </>
              )}
            </div>
          )}

          {/* Step 4: Compare Results */}
          {step >= 4 && compareResult && (
            <div className="animate-fade-in mt-5">
              <Divider />
              <div className="step-indicator mb-4">
                <i className="pi pi-chart-line"></i>
                Step 5: Comparison Results
              </div>
              <CompareView
                result={compareResult}
                newerLabel={`${shortHash(newerCommit?.hash)} - ${newerCommit?.message?.split('\n')[0]?.slice(0, 30) || ''}`}
                olderLabel={`${shortHash(olderCommit?.hash)} - ${olderCommit?.message?.split('\n')[0]?.slice(0, 30) || ''}`}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
