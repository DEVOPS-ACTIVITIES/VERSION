import { Card } from 'primereact/card'
import { Button } from 'primereact/button'

export default function LandingPage({ onSelect }) {
  return (
    <div className="flex flex-column align-items-center justify-content-center" style={{ minHeight: '100vh' }}>
      {/* Hero Header */}
      <div className="text-center mb-6 animate-fade-in">
        <div className="mb-3">
          <span style={{
            fontSize: '4rem',
            filter: 'drop-shadow(0 4px 8px rgba(0,0,0,0.3))'
          }}>📊</span>
        </div>
        <h1 style={{
          color: 'white',
          fontSize: '2.8rem',
          fontWeight: '800',
          margin: '0 0 12px',
          textShadow: '0 2px 10px rgba(0,0,0,0.2)',
          letterSpacing: '-0.5px'
        }}>
          Excel File Versioning
        </h1>
        <p style={{
          color: 'rgba(255,255,255,0.85)',
          fontSize: '1.15rem',
          maxWidth: '500px',
          margin: '0 auto',
          lineHeight: '1.6'
        }}>
          Compare Excel &amp; ZIP files across versions with intelligent word-level highlighting
        </p>
      </div>

      {/* Option Cards */}
      <div className="flex gap-4 flex-wrap justify-content-center animate-fade-in" style={{ maxWidth: '700px' }}>
        {/* GCS Option */}
        <div
          className="source-option-card"
          onClick={() => onSelect('gcs')}
          style={{
            width: '300px',
            background: 'white',
            borderRadius: '20px',
            padding: '36px 28px',
            textAlign: 'center',
            boxShadow: '0 8px 32px rgba(0,0,0,0.15)',
            cursor: 'pointer'
          }}
        >
          <div className="source-icon-circle mb-4" style={{
            background: 'linear-gradient(135deg, #4285f4 0%, #34a853 100%)',
          }}>
            <i className="pi pi-cloud" style={{ color: 'white', fontSize: '2rem' }}></i>
          </div>
          <h3 style={{ margin: '0 0 10px', color: '#1e293b', fontSize: '1.4rem', fontWeight: '700' }}>
            Google Cloud Storage
          </h3>
          <p style={{ color: '#64748b', margin: '0 0 24px', lineHeight: '1.5', fontSize: '0.95rem' }}>
            Connect to a GCS bucket to browse and compare versioned Excel &amp; ZIP files
          </p>
          <div className="flex flex-wrap gap-2 justify-content-center mb-4">
            {['Bucket', 'Prefix', 'Versions'].map(tag => (
              <span key={tag} style={{
                background: '#eff6ff',
                color: '#3b82f6',
                padding: '4px 12px',
                borderRadius: '20px',
                fontSize: '0.8rem',
                fontWeight: '600'
              }}>{tag}</span>
            ))}
          </div>
          <Button
            label="Connect to GCS"
            icon="pi pi-arrow-right"
            iconPos="right"
            style={{
              background: 'linear-gradient(135deg, #4285f4 0%, #34a853 100%)',
              border: 'none',
              borderRadius: '10px',
              padding: '10px 24px',
              width: '100%',
              fontWeight: '600'
            }}
          />
        </div>

        {/* GitHub Option */}
        <div
          className="source-option-card"
          onClick={() => onSelect('github')}
          style={{
            width: '300px',
            background: 'white',
            borderRadius: '20px',
            padding: '36px 28px',
            textAlign: 'center',
            boxShadow: '0 8px 32px rgba(0,0,0,0.15)',
            cursor: 'pointer'
          }}
        >
          <div className="source-icon-circle mb-4" style={{
            background: 'linear-gradient(135deg, #24292e 0%, #6e40c9 100%)',
          }}>
            <i className="pi pi-github" style={{ color: 'white', fontSize: '2rem' }}></i>
          </div>
          <h3 style={{ margin: '0 0 10px', color: '#1e293b', fontSize: '1.4rem', fontWeight: '700' }}>
            GitHub Repository
          </h3>
          <p style={{ color: '#64748b', margin: '0 0 24px', lineHeight: '1.5', fontSize: '0.95rem' }}>
            Connect to a GitHub repository to compare files between commits and branches
          </p>
          <div className="flex flex-wrap gap-2 justify-content-center mb-4">
            {['Branches', 'Commits', 'Diff'].map(tag => (
              <span key={tag} style={{
                background: '#f5f3ff',
                color: '#6d28d9',
                padding: '4px 12px',
                borderRadius: '20px',
                fontSize: '0.8rem',
                fontWeight: '600'
              }}>{tag}</span>
            ))}
          </div>
          <Button
            label="Connect to GitHub"
            icon="pi pi-arrow-right"
            iconPos="right"
            style={{
              background: 'linear-gradient(135deg, #24292e 0%, #6e40c9 100%)',
              border: 'none',
              borderRadius: '10px',
              padding: '10px 24px',
              width: '100%',
              fontWeight: '600'
            }}
          />
        </div>
      </div>

      <p style={{ color: 'rgba(255,255,255,0.6)', marginTop: '40px', fontSize: '0.85rem' }}>
        Powered by Flask + PrimeReact
      </p>
    </div>
  )
}
